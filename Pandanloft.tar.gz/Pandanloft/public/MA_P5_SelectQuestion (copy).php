<!DOCTYPE html>
<html>

<head>
<title>Pandanloft Math P5</title>
<meta content="noindex, nofollow" name="robots">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="./css/style.css" rel="stylesheet" type="text/css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>

<script>
$(document).ready(function(){
   $("#VerifyAnswer").click(function(){
   
<?php
$u=$_GET["u"];
$l=$_GET["l"];

echo "var var_u='$u';";
echo "var var_l='$l';";
?>
   
    var data1="jkkk";
//    alert("fms-1:"+data1);
    var e=document.getElementById("users");
    var value=e.options[e.selectedIndex].text;
    var value1='q=' + value;
    value1=value1+"&&u="+var_u+"&&l="+var_l;
           	console.log(value1);
    $.post("handlers/MA_PostAnswer.php",value1,function(data){
    	console.log(data);
//	alert("data is:"+ data);
	$("#answerhint").html(data);
        
    });
  });
});
</script>
;
</head>


<body>

<header>
<h1> Pandanloft Enrichment P5 Math
<img src="../public/images/pandanloft_logo.jpg" style="width: 4%; height: auto;">
</h1>
<hr>
</header>

<script type="text/javascript">
function showQuestion(str)
{

<?php
$u=$_GET["u"];
$l=$_GET["l"];
//echo "<script>console.log('u={$u}' );</script>";
//echo "<script>console.log('l={$l}' );</script>";

echo "var var_u='$u';";
echo "var var_l='$l';";
?>

console.log("showQuestion-input:"+str+","+var_u+","+var_l);  

if (str=="")
  {
  document.getElementById("txtHint").innerHTML="";
  return;
  } 	
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("GET","handlers/MA_GetQuestion.php?q="+str+"&&u="+var_u+"&&l="+var_l,true);
xmlhttp.send();

$("#answerhint").html('');
}
</script>

<main>
<div class="topnav">
      <a href="../index.php">Home</a>
      <a href="./MA_P5.php">P5 Math</a>
      <a href="./MA_P6.php">P6 Math</a>
      <a href="./MU_T1.php">L1 Theory</a>
      <a href="./MU_T2.php">L2 Theory</a>
      <a href="../index.php">About</a>
</div>

<section>
  <nav id="leftnav">
    <ul>
      <li><a href="./MA_P5_SelectQuestion.php?u=1&&l=P5">Unit 1</a></li>
      <li><a href="./MA_P5_SelectQuestion.php?u=2&&l=P5">Unit 2</a></li>
      <li><a href="./MA_P5_SelectQuestion.php?u=3&&l=P5">Unit 3</a></li>
      <li><a href="./MA_P5_SelectQuestion.php?u=4&&l=P5">Unit 4</a></li>
      <li><a href="./MA_P5_SelectQuestion.php?u=5&&l=P5">Unit 5</a></li>
      <li><a href="./MA_P5_SelectQuestion.php?u=6&&l=P5">Unit 6</a></li>
      <li><a href="./MA_P5_SelectQuestion.php?u=7&&l=P5">Unit 7</a></li>
      <li><a href="./MA_P5_SelectQuestion.php?u=8&&l=P5">Unit 8</a></li>
     </ul>
  </nav>

<article>
<div>
<em>Welcome to Primary 5 Mathematics Garden! </em> <br><br><br>
Select a question:
</div>

<form>
<select id="users" name="users" onchange="showQuestion(this.value)"> 
<option value="">Select a question:</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
</select>
</form>

<br />
<div id="txtHint"><b>Question info will be listed here.</b></div>

<h3 id="answer"> Selected answer is: ______________ </h3><hr>
<button id="VerifyAnswer">Verify Answer</button>
<div id="answerhint"> <p>...</p></div>

</article>
</section>

<?php
 include_once 'common/bottom.php';
?>

