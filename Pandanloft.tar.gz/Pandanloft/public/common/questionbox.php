
<form>
<select id="users" name="users" onchange="showQuestion(this.value)">
<option value="">Select a question:</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
</select>
</form>

<br />
<div id="txtHint"><b>Question info will be listed here.</b></div>

<h3 id="answer"> Selected answer is: ______________ </h3><hr>
<button id="VerifyAnswer">Verify Answer</button>
<div id="answerhint"> <p>...</p></div>


</article>

