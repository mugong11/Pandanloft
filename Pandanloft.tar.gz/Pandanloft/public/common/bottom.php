    </main>
    <footer role="contentinfo">
        Copyright <?php echo date('Y') ?> Pandanloft Enrichment&reg <br>
    </footer>
    <script src="/js/data.js"></script>
    <script src="/js/user.js"></script>
</body>
</html>
