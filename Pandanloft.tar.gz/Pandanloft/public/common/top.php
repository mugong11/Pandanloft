<!DOCTYPE html>
<html lang="n">
<head>
<meta content="noindex, nofollow" name="robots">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1,0">
<title><?php echo $page_title ?> | Pandanloft Enrichment</title>
<link rel="icon" type="image/x-icon" href="./images/pandanloft.ico">
<link href="css/style.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>

<script type="text/x-mathjax-config">
  MathJax.Hub.Config({
  tex2jax: {inlineMath: [['$','$'], ['\\(','\\)']]},
      "HTML-CSS" : {
        availableFonts : ["STIX General","Asana Math","Neo Euler","Gyre Pagella","Gyre Termes","Latin Modern","MathJax TeX","STIX"],
        preferredFont : "STIX",
        webFont : "STIX-Web",
        imageFont : null
    }
  });
</script>
<script type="text/javascript"
  src="https://cdn.mathjax.org/mathjax/latest/MathJax.js?config=TeX-AMS-MML_HTMLorMML">
</script>

</head>

<body>
<header role="banner">
<h1> Pandanloft Enrichment 
<img src="images/pandanloft_logo.jpg" style="width: 4%; height: auto;">
</h1>
<hr>

<div class="top-header-user">
<?php
    if(isset($_SESSION['username'])):
?>    
      
      <button id="show-user-account-button" class="btn-plain">Your Account</button>
      <button id="user-sign-out-button" class="btn">Sign Out</button>
      <div class="topnav">
	      <a href="index.php">Home</a>
	      <a href="MA_P6.php">P6 Math</a>
	      <a href="MA_P5.php">P5 Math</a>
	      <a href="MA_Olevel.php">O-level Math</a>
<!--
      <a href="MU_T1.php">L1 Theory</a>
      <a href="MU_T2.php">L2 Theory</a>
-->      
	      <a href="about.php">About</a>
      </div>

<?php
    else:
?>    
      <button id="show-sign-in-page-button" class="btn-plain">Sign In</button>
      <button id="show-sign-up-page-button" class="btn">Sign Up</button>
      <div class="topnav">
	      <a href="index.php">Home</a>
	      <a href="about.php">About</a>
      </div>

<?php
    endif;
?>    
</div>
        
</header>
<main role="main">
