<section>
  <nav>
    <ul>
      <li><a href="./FullQuestion.php?l=<?php echo $class ?>">All</a></li><br>
      <li><a href="./ProblemQuestion.php?l=<?php echo $class ?>&&p=whole_numbers">WholeNum</a></li>
      <li><a href="./ProblemQuestion.php?l=<?php echo $class ?>&&p=decimals">Decimals</a></li>
      <li><a href="./ProblemQuestion.php?l=<?php echo $class ?>&&p=fractions">Fractions</a></li>
      <li><a href="./ProblemQuestion.php?l=<?php echo $class ?>&&p=percentage">Percentage</a></li>
      <li><a href="./ProblemQuestion.php?l=<?php echo $class ?>&&p=ratio">Ratio</a></li>
      <li><a href="./ProblemQuestion.php?l=<?php echo $class ?>&&p=rate">Rate/Speed</a></li>
      <li><a href="./ProblemQuestion.php?l=<?php echo $class ?>&&p=algebra">Algebra</a></li>
      <li><a href="./ProblemQuestion.php?l=<?php echo $class ?>&&p=geometry">Geometry</a></li>
      <li><a href="./ProblemQuestion.php?l=<?php echo $class ?>&&p=statistics">Statistics</a></li>
      <li><a href="./ProblemQuestion.php?l=<?php echo $class ?>&&p=logic">Logic</a></li><br>

      <li><a href="./DifficultyQuestion.php?l=<?php echo $class ?>&&d=E">&#x1F3C5;&#x1F3C5</a></li>
      <li><a href="./DifficultyQuestion.php?l=<?php echo $class ?>&&d=M">&#x1F3C5;&#x1F3C5;&#x1F3C5;</a></li>
      <li><a href="./DifficultyQuestion.php?l=<?php echo $class ?>&&d=A">&#x1F3C5;&#x1F3C5;&#x1F3C5;&#x1F3C5;</a></li><br>


      <li><a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=1">Assess1</a></li>
      <li><a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=2">Assess2</a></li>
      <li><a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=3">Assess3</a></li>
      <li><a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=4">Assess4</a></li>
      <li><a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=5">Assess5</a></li><br>
      
      <li><a href="./MA_UnitQuestion.php?u=1&&l=<?php echo $class ?>">Unit 1</a></li>
      <li><a href="./MA_UnitQuestion.php?u=2&&l=<?php echo $class ?>">Unit 2</a></li>
      <li><a href="./MA_UnitQuestion.php?u=3&&l=<?php echo $class ?>">Unit 3</a></li>
      <li><a href="./MA_UnitQuestion.php?u=4&&l=<?php echo $class ?>">Unit 4</a></li>
      <li><a href="./MA_UnitQuestion.php?u=5&&l=<?php echo $class ?>">Unit 5</a></li>
      <li><a href="./MA_UnitQuestion.php?u=6&&l=<?php echo $class ?>">Unit 6</a></li>
      <li><a href="./MA_UnitQuestion.php?u=7&&l=<?php echo $class ?>">Unit 7</a></li>
      <li><a href="./MA_UnitQuestion.php?u=8&&l=<?php echo $class ?>">Unit 8</a></li>
      <li><a href="./MA_UnitQuestion.php?u=9&&l=<?php echo $class ?>">Unit 9</a></li>
      <li><a href="./MA_UnitQuestion.php?u=10&&l=<?php echo $class ?>">Unit 10</a></li>
      <li><a href="./MA_UnitQuestion.php?u=11&&l=<?php echo $class ?>">Unit 11</a></li>
      <li><a href="./MA_UnitQuestion.php?u=12&&l=<?php echo $class ?>">Unit 12</a></li>
      <li><a href="./MA_UnitQuestion.php?u=13&&l=<?php echo $class ?>">Unit 13</a></li>
      <li><a href="./MA_UnitQuestion.php?u=14&&l=<?php echo $class ?>">Unit 14</a></li>
      <li><a href="./MA_UnitQuestion.php?u=15&&l=<?php echo $class ?>">Unit 15</a></li>
      <li><a href="./MA_UnitQuestion.php?u=16&&l=<?php echo $class ?>">Unit 16</a></li>
      <li><a href="./MA_UnitQuestion.php?u=17&&l=<?php echo $class ?>">Unit 17</a></li>
      <li><a href="./MA_UnitQuestion.php?u=18&&l=<?php echo $class ?>">Unit 18</a></li>
      <li><a href="./MA_UnitQuestion.php?u=19&&l=<?php echo $class ?>">Unit 19</a></li>
      <li><a href="./MA_UnitQuestion.php?u=20&&l=<?php echo $class ?>">Unit 20</a></li><br>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=2&&l=<?php echo $class ?>">Unit 1*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=2&&l=<?php echo $class ?>">Unit 2*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=3&&l=<?php echo $class ?>">Unit 3*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=4&&l=<?php echo $class ?>">Unit 4*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=5&&l=<?php echo $class ?>">Unit 5*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=6&&l=<?php echo $class ?>">Unit 6*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=7&&l=<?php echo $class ?>">Unit 7*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=8&&l=<?php echo $class ?>">Unit 8*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=9&&l=<?php echo $class ?>">Unit 9*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=10&&l=<?php echo $class ?>">Unit 10*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=11&&l=<?php echo $class ?>">Unit 11*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=12&&l=<?php echo $class ?>">Unit 12*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=13&&l=<?php echo $class ?>">Unit 13*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=14&&l=<?php echo $class ?>">Unit 14*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=15&&l=<?php echo $class ?>">Unit 15*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=16&&l=<?php echo $class ?>">Unit 16*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=17&&l=<?php echo $class ?>">Unit 17*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=18&&l=<?php echo $class ?>">Unit 18*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=19&&l=<?php echo $class ?>">Unit 19*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=20&&l=<?php echo $class ?>">Unit 20*</a></li>
    </ul>
  </nav>

<article>
<div>
Welcome to <?php echo $class_msg ?> Garden !
</div>



