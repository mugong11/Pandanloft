<section>
  <nav>
    <ul>
      <li><a href="./FullQuestion.php?l=<?php echo $class ?>&&u=0">All</a></li><br>
      <li><a href="./ProblemQuestion.php?l=<?php echo $class ?>&&p=whole_numbers&&u=0">WholeNum</a></li>
      <li><a href="./ProblemQuestion.php?l=<?php echo $class ?>&&p=decimals&&u=0">Decimals</a></li>
      <li><a href="./ProblemQuestion.php?l=<?php echo $class ?>&&p=fractions&&u=0">Fractions</a></li>
      <li><a href="./ProblemQuestion.php?l=<?php echo $class ?>&&p=percentage&&u=0">Percentage</a></li>
      <li><a href="./ProblemQuestion.php?l=<?php echo $class ?>&&p=ratio&&u=0">Ratio</a></li>
      <li><a href="./ProblemQuestion.php?l=<?php echo $class ?>&&p=rate&&u=0">Rate/Speed</a></li>
      <li><a href="./ProblemQuestion.php?l=<?php echo $class ?>&&p=algebra&&u=0">Algebra</a></li>
      <li><a href="./ProblemQuestion.php?l=<?php echo $class ?>&&p=geometry&&u=0">Geometry</a></li>
      <li><a href="./ProblemQuestion.php?l=<?php echo $class ?>&&p=statistics&&u=0">Statistics</a></li>
      <li><a href="./ProblemQuestion.php?l=<?php echo $class ?>&&p=logic&&u=0">Logic</a></li><br>

      <li><a href="./DifficultyQuestion.php?l=<?php echo $class ?>&&d=E&&u=0">&#x1F3C5;&#x1F3C5</a></li>
      <li><a href="./DifficultyQuestion.php?l=<?php echo $class ?>&&d=M&&u=0">&#x1F3C5;&#x1F3C5;&#x1F3C5;</a></li>
      <li><a href="./DifficultyQuestion.php?l=<?php echo $class ?>&&d=A&&u=0">&#x1F3C5;&#x1F3C5;&#x1F3C5;&#x1F3C5;</a></li><br>

      <li><a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=22&&u=0">Elite 2023 #2</a></li>
      <li><a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=21&&u=0">Elite 2023 #1</a></li><br>

      <li><a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=25&&u=0">Preliminary 2023 #3</a></li>
      <li><a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=24&&u=0">Preliminary 2023 #2</a></li>
      <li><a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=23&&u=0">Preliminary 2023 #1</a></li><br>

      <li><a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=20&&u=0">Assess20</a></li>
      <li><a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=19&&u=0">Assess19</a></li>
      <li><a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=18&&u=0">Assess18</a></li>
      <li><a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=17&&u=0">Assess17</a></li>
      <li><a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=16&&u=0">Assess16</a></li>
      <li><a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=15&&u=0">Assess15</a></li>
      <li><a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=14&&u=0">Assess14</a></li>
      <li><a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=13&&u=0">Assess13</a></li>
      <li><a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=12&&u=0">Assess12</a></li>
      <li><a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=11&&u=0">Assess11</a></li>
      <li><a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=10&&u=0">Assess10</a></li>
      <li><a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=9&&u=0">Assess9</a></li>
      <li><a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=8&&u=0">Assess8</a></li>
      <li><a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=7&&u=0">Assess7</a></li>
      <li><a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=6&&u=0">Assess6</a></li>
      <li><a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=5&&u=0">Assess5</a></li>
      <li><a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=4&&u=0">Assess4</a></li>
      <li><a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=3&&u=0">Assess3</a></li>
      <li><a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=2&&u=0">Assess2</a></li>
      <li><a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=1&&u=0">Assess1</a></li>
      <br>
      
      <li><a href="./MA_UnitQuestion.php?u=1&&l=<?php echo $class ?>">Unit 1</a></li>
      <li><a href="./MA_UnitQuestion.php?u=2&&l=<?php echo $class ?>">Unit 2</a></li>
      <li><a href="./MA_UnitQuestion.php?u=3&&l=<?php echo $class ?>">Unit 3</a></li>
      <li><a href="./MA_UnitQuestion.php?u=4&&l=<?php echo $class ?>">Unit 4</a></li>
      <li><a href="./MA_UnitQuestion.php?u=5&&l=<?php echo $class ?>">Unit 5</a></li>
      <li><a href="./MA_UnitQuestion.php?u=6&&l=<?php echo $class ?>">Unit 6</a></li>
      <li><a href="./MA_UnitQuestion.php?u=7&&l=<?php echo $class ?>">Unit 7</a></li>
      <li><a href="./MA_UnitQuestion.php?u=8&&l=<?php echo $class ?>">Unit 8</a></li>
      <li><a href="./MA_UnitQuestion.php?u=9&&l=<?php echo $class ?>">Unit 9</a></li>
      <li><a href="./MA_UnitQuestion.php?u=10&&l=<?php echo $class ?>">Unit 10</a></li>
      <li><a href="./MA_UnitQuestion.php?u=11&&l=<?php echo $class ?>">Unit 11</a></li>
      <li><a href="./MA_UnitQuestion.php?u=12&&l=<?php echo $class ?>">Unit 12</a></li>
      <li><a href="./MA_UnitQuestion.php?u=13&&l=<?php echo $class ?>">Unit 13</a></li>
      <li><a href="./MA_UnitQuestion.php?u=14&&l=<?php echo $class ?>">Unit 14</a></li>
      <li><a href="./MA_UnitQuestion.php?u=15&&l=<?php echo $class ?>">Unit 15</a></li>
      <li><a href="./MA_UnitQuestion.php?u=16&&l=<?php echo $class ?>">Unit 16</a></li>
      <li><a href="./MA_UnitQuestion.php?u=17&&l=<?php echo $class ?>">Unit 17</a></li>
      <li><a href="./MA_UnitQuestion.php?u=18&&l=<?php echo $class ?>">Unit 18</a></li>
      <li><a href="./MA_UnitQuestion.php?u=19&&l=<?php echo $class ?>">Unit 19</a></li>
      <li><a href="./MA_UnitQuestion.php?u=20&&l=<?php echo $class ?>">Unit 20</a></li><br>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=2&&l=<?php echo $class ?>">Unit 1*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=2&&l=<?php echo $class ?>">Unit 2*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=3&&l=<?php echo $class ?>">Unit 3*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=4&&l=<?php echo $class ?>">Unit 4*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=5&&l=<?php echo $class ?>">Unit 5*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=6&&l=<?php echo $class ?>">Unit 6*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=7&&l=<?php echo $class ?>">Unit 7*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=8&&l=<?php echo $class ?>">Unit 8*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=9&&l=<?php echo $class ?>">Unit 9*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=10&&l=<?php echo $class ?>">Unit 10*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=11&&l=<?php echo $class ?>">Unit 11*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=12&&l=<?php echo $class ?>">Unit 12*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=13&&l=<?php echo $class ?>">Unit 13*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=14&&l=<?php echo $class ?>">Unit 14*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=15&&l=<?php echo $class ?>">Unit 15*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=16&&l=<?php echo $class ?>">Unit 16*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=17&&l=<?php echo $class ?>">Unit 17*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=18&&l=<?php echo $class ?>">Unit 18*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=19&&l=<?php echo $class ?>">Unit 19*</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=20&&l=<?php echo $class ?>">Unit 20*</a></li>
    </ul>
  </nav>


<article>
<div>
Welcome to <?php echo $class_msg ?> Garden !
<br>
</div>
<div id="content">


