<section>
  <nav>
    <ul>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=1&&l=<?php echo $class ?>">Unit 1</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=2&&l=<?php echo $class ?>">Unit 2</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=3&&l=<?php echo $class ?>">Unit 3</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=4&&l=<?php echo $class ?>">Unit 4</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=5&&l=<?php echo $class ?>">Unit 5</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=6&&l=<?php echo $class ?>">Unit 6</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=7&&l=<?php echo $class ?>">Unit 7</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=8&&l=<?php echo $class ?>">Unit 8</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=9&&l=<?php echo $class ?>">Unit 9</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=10&&l=<?php echo $class ?>">Unit 10</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=11&&l=<?php echo $class ?>">Unit 11</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=12&&l=<?php echo $class ?>">Unit 12</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=13&&l=<?php echo $class ?>">Unit 13</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=14&&l=<?php echo $class ?>">Unit 14</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=15&&l=<?php echo $class ?>">Unit 15</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=16&&l=<?php echo $class ?>">Unit 16</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=17&&l=<?php echo $class ?>">Unit 17</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=18&&l=<?php echo $class ?>">Unit 18</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=19&&l=<?php echo $class ?>">Unit 19</a></li>
      <li><a href="./<?php echo $class ?>_SelectQuestion.php?u=20&&l=<?php echo $class ?>">Unit 20</a></li>
      <li><a href="./FullQuestion.php?l=<?php echo $class ?>">All</a></li>
    </ul>
  </nav>

<article>
<div>
Welcome to <?php echo $class_msg ?> Garden !
</div>



