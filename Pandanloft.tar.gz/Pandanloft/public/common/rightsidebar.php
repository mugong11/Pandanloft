<aside role="complementary">
<h3> More Links
</h3>

<a href="http://pandanloft.blogspot.com" target="_blank"> <strong>Find more story as here </strong></a> <br><br>

<iframe width="100%" height="100%" src="https://www.youtube.com/embed/4DfZlORz0uw?controls=0">
</iframe>
<iframe width="100%" height="100%" src="https://www.youtube.com/embed/9YNvBdAuiXc?controls=0">
</iframe>
<iframe width="100%" height="100%" src="https://www.youtube.com/embed/nQqPyLcmuyo?controls=0">
</iframe>
</aside>
</section>
