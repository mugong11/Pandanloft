 <div class="dropdown-content">
      <a href="./FullQuestion.php?l=<?php echo $class ?>&&u=0">All</a><br>
      <a href="./ProblemQuestion.php?l=<?php echo $class ?>&&p=whole_numbers&&u=0">WholeNum</a>
      <a href="./ProblemQuestion.php?l=<?php echo $class ?>&&p=decimals&&u=0">Decimals</a>
      <a href="./ProblemQuestion.php?l=<?php echo $class ?>&&p=fractions&&u=0">Fractions</a>
      <a href="./ProblemQuestion.php?l=<?php echo $class ?>&&p=percentage&&u=0">Percentage</a>
      <a href="./ProblemQuestion.php?l=<?php echo $class ?>&&p=ratio&&u=0">Ratio</a>
      <a href="./ProblemQuestion.php?l=<?php echo $class ?>&&p=rate&&u=0">Rate/Speed</a>
      <a href="./ProblemQuestion.php?l=<?php echo $class ?>&&p=algebra&&u=0">Algebra</a>
      <a href="./ProblemQuestion.php?l=<?php echo $class ?>&&p=geometry&&u=0">Geometry</a>
      <a href="./ProblemQuestion.php?l=<?php echo $class ?>&&p=statistics&&u=0">Statistics</a>
      <a href="./ProblemQuestion.php?l=<?php echo $class ?>&&p=logic&&u=0">Logic</a><br>

      <a href="./DifficultyQuestion.php?l=<?php echo $class ?>&&d=E&&u=0">&#x1F3C5;&#x1F3C5</a>
      <a href="./DifficultyQuestion.php?l=<?php echo $class ?>&&d=M&&u=0">&#x1F3C5;&#x1F3C5;&#x1F3C5;</a>
      <a href="./DifficultyQuestion.php?l=<?php echo $class ?>&&d=A&&u=0">&#x1F3C5;&#x1F3C5;&#x1F3C5;&#x1F3C5;</a><br>

      <a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=9&&u=0">Assess9</a>
      <a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=8&&u=0">Assess8</a>
      <a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=7&&u=0">Assess7</a>
      <a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=6&&u=0">Assess6</a>
      <a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=5&&u=0">Assess5</a>
      <a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=4&&u=0">Assess4</a>
      <a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=3&&u=0">Assess3</a>
      <a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=2&&u=0">Assess2</a>
      <a href="./AssessmentQuestion.php?l=<?php echo $class ?>&&a=1&&u=0">Assess1</a>
      <br>
      
      <a href="./MA_UnitQuestion.php?u=1&&l=<?php echo $class ?>">Unit 1</a>
      <a href="./MA_UnitQuestion.php?u=2&&l=<?php echo $class ?>">Unit 2</a>
      <a href="./MA_UnitQuestion.php?u=3&&l=<?php echo $class ?>">Unit 3</a>
      <a href="./MA_UnitQuestion.php?u=4&&l=<?php echo $class ?>">Unit 4</a>
      <a href="./MA_UnitQuestion.php?u=5&&l=<?php echo $class ?>">Unit 5</a>
      <a href="./MA_UnitQuestion.php?u=6&&l=<?php echo $class ?>">Unit 6</a>
      <a href="./MA_UnitQuestion.php?u=7&&l=<?php echo $class ?>">Unit 7</a>
      <a href="./MA_UnitQuestion.php?u=8&&l=<?php echo $class ?>">Unit 8</a>
      <a href="./MA_UnitQuestion.php?u=9&&l=<?php echo $class ?>">Unit 9</a>
      <a href="./MA_UnitQuestion.php?u=10&&l=<?php echo $class ?>">Unit 10</a>
      <a href="./MA_UnitQuestion.php?u=11&&l=<?php echo $class ?>">Unit 11</a>
      <a href="./MA_UnitQuestion.php?u=12&&l=<?php echo $class ?>">Unit 12</a>
      <a href="./MA_UnitQuestion.php?u=13&&l=<?php echo $class ?>">Unit 13</a>
      <a href="./MA_UnitQuestion.php?u=14&&l=<?php echo $class ?>">Unit 14</a>
      <a href="./MA_UnitQuestion.php?u=15&&l=<?php echo $class ?>">Unit 15</a>
      <a href="./MA_UnitQuestion.php?u=16&&l=<?php echo $class ?>">Unit 16</a>
      <a href="./MA_UnitQuestion.php?u=17&&l=<?php echo $class ?>">Unit 17</a>
      <a href="./MA_UnitQuestion.php?u=18&&l=<?php echo $class ?>">Unit 18</a>
      <a href="./MA_UnitQuestion.php?u=19&&l=<?php echo $class ?>">Unit 19</a>
      <a href="./MA_UnitQuestion.php?u=20&&l=<?php echo $class ?>">Unit 20</a><br>
      <a href="./<?php echo $class ?>_SelectQuestion.php?u=2&&l=<?php echo $class ?>">Unit 1*</a>
      <a href="./<?php echo $class ?>_SelectQuestion.php?u=2&&l=<?php echo $class ?>">Unit 2*</a>
      <a href="./<?php echo $class ?>_SelectQuestion.php?u=3&&l=<?php echo $class ?>">Unit 3*</a>
      <a href="./<?php echo $class ?>_SelectQuestion.php?u=4&&l=<?php echo $class ?>">Unit 4*</a>
      <a href="./<?php echo $class ?>_SelectQuestion.php?u=5&&l=<?php echo $class ?>">Unit 5*</a>
      <a href="./<?php echo $class ?>_SelectQuestion.php?u=6&&l=<?php echo $class ?>">Unit 6*</a>
      <a href="./<?php echo $class ?>_SelectQuestion.php?u=7&&l=<?php echo $class ?>">Unit 7*</a>
      <a href="./<?php echo $class ?>_SelectQuestion.php?u=8&&l=<?php echo $class ?>">Unit 8*</a>
      <a href="./<?php echo $class ?>_SelectQuestion.php?u=9&&l=<?php echo $class ?>">Unit 9*</a>
      <a href="./<?php echo $class ?>_SelectQuestion.php?u=10&&l=<?php echo $class ?>">Unit 10*</a>
      <a href="./<?php echo $class ?>_SelectQuestion.php?u=11&&l=<?php echo $class ?>">Unit 11*</a>
      <a href="./<?php echo $class ?>_SelectQuestion.php?u=12&&l=<?php echo $class ?>">Unit 12*</a>
      <a href="./<?php echo $class ?>_SelectQuestion.php?u=13&&l=<?php echo $class ?>">Unit 13*</a>
      <a href="./<?php echo $class ?>_SelectQuestion.php?u=14&&l=<?php echo $class ?>">Unit 14*</a>
      <a href="./<?php echo $class ?>_SelectQuestion.php?u=15&&l=<?php echo $class ?>">Unit 15*</a>
      <a href="./<?php echo $class ?>_SelectQuestion.php?u=16&&l=<?php echo $class ?>">Unit 16*</a>
      <a href="./<?php echo $class ?>_SelectQuestion.php?u=17&&l=<?php echo $class ?>">Unit 17*</a>
      <a href="./<?php echo $class ?>_SelectQuestion.php?u=18&&l=<?php echo $class ?>">Unit 18*</a>
      <a href="./<?php echo $class ?>_SelectQuestion.php?u=19&&l=<?php echo $class ?>">Unit 19*</a>
      <a href="./<?php echo $class ?>_SelectQuestion.php?u=20&&l=<?php echo $class ?>">Unit 20*</a>
</div>
