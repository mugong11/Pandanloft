<?php
 $page_title = "P5 Math";
 include_once '../private/common/initialization.php';
 include_once 'common/top.php';
 include_once 'handlers/MA_DisplayQuestion.php'
?>

<?php
 $class = "MA_P5";
 $class_msg = "Mathemtics (Primary 5)";
 include_once 'common/leftnav.php';
?>

<?php
 include_once 'common/questionbox.php';
?>
<script>
scrollFunction();
</script>

<?php
 include_once 'common/rightsidebar.php';
 include_once 'common/bottom.php';
?>

