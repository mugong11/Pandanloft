<?php
 $page_title = "P5 Math";
 include_once 'common/top.php';
 include_once 'handlers/MA_DisplayQuestion.php'
?>

<section>
  <nav id="leftnav">
    <ul>
      <li><a href="./MA_P5_SelectQuestion.php?u=1&&l=P5">Unit 1</a></li>
      <li><a href="./MA_P5_SelectQuestion.php?u=2&&l=P5">Unit 2</a></li>
      <li><a href="./MA_P5_SelectQuestion.php?u=3&&l=P5">Unit 3</a></li>
      <li><a href="./MA_P5_SelectQuestion.php?u=4&&l=P5">Unit 4</a></li>
      <li><a href="./MA_P5_SelectQuestion.php?u=5&&l=P5">Unit 5</a></li>
      <li><a href="./MA_P5_SelectQuestion.php?u=6&&l=P5">Unit 6</a></li>
      <li><a href="./MA_P5_SelectQuestion.php?u=7&&l=P5">Unit 7</a></li>
      <li><a href="./MA_P5_SelectQuestion.php?u=8&&l=P5">Unit 8</a></li>
     </ul>
  </nav>

<article>
<div>
<em>Welcome to Primary 5 Mathematics Garden! </em> <br><br><br>
Select a question:
</div>

<form>
<select id="users" name="users" onchange="showQuestion(this.value)"> 
<option value="">Select a question:</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
</select>
</form>

<br />
<div id="txtHint"><b>Question info will be listed here.</b></div>

<h3 id="answer"> Selected answer is: ______________ </h3><hr>
<button id="VerifyAnswer">Verify Answer</button>
<div id="answerhint"> <p>...</p></div>

</article>
</section>

<?php
 include_once 'common/bottom.php';
?>

