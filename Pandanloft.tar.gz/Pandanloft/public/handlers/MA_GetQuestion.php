<?php
 include_once '../../private/common/initialization.php';

$u=$_GET["u"];
$q=$_GET["q"];
$l=$_GET["l"];
//$u="1";
//$q="1";
//echo "<script>console.log('u={$u}' );</script>";
//echo "<script>console.log('q={$q}' );</script>";


//$connection = mysqli_connect($HOST,$USER,$PASSWORD,$DATABASE) or die ("Issue on connecting mysql");
$connection = $mysqli;

//Get question
//$query="select question_id, description from ma_question where question_id='".$q."'";
$query="select ma_question.question_id,ma_question.description from ma_question, ma_unit where ma_unit.question_id=ma_question.question_id and ma_unit.unit_id='{$u}' and ma_unit.unit_rownum='{$q}' and ma_question.level_id='{$l}'";

//`echo "<script>console.log({$query} );</script>";

echo "<table border='1'>
<tr> 
<th>question</th>
</tr>";

$result = mysqli_query ($connection, $query) or die ("Issue on retrieving data");

while ($row = mysqli_fetch_array ($result)) {
$question_id= $row['question_id'];
$description= $row['description'];
echo "<tr><td>$description</td></tr>";
};


echo "</table>";

//Get Graph
   
$sql = "select question_id,graph_question from ma_question_graph where question_id='".$question_id."'";
if (!$result=mysqli_query($connection, $sql)){
echo mysqli_error($connection);
}
else {
$row = mysqli_fetch_array($result);
echo '<img src="data:image/jpeg;base64,'.base64_encode($row['graph_question']).'"/>';
}



//Get answer
$query = "select ma_choice.choice_id c_id,ma_choice.description c_d from ma_question, ma_choice where ma_question.question_id=ma_choice.question_id and ma_question.question_id='".$question_id."'";


//echo "<table border='1'><tr> <th>id</th><th>answer</th></tr><br><br>";
echo "<p>choose one of answer:<br></p>";
echo "<ol>";

$result = mysqli_query ($connection, $query) or die ("Issue on retrieving data");

while ($row = mysqli_fetch_array ($result)) {
$choice_id= $row['c_id'];
$description= $row['c_d'];
//echo "<tr><td>$choice_id</td><td>$description</td></tr>";
echo "<li>$description</li>";
};

mysqli_close($connection);
?>


