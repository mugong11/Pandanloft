<?php
include_once '../../private/common/initialization.php';
 
$u=$_POST["u"];
$q=$_POST["q"];
$l=$_POST["l"];

//$connection = mysqli_connect($HOST,$USER,$PASSWORD,$DATABASE) or die ("Issue on connecting mysql");
//$connection = mysqli_connect("localhost","test","test","Pandan01") or die ("Issue on connecting mysql");
$connection = $mysqli;

//Get answer
if ($u == "F") {

$query = "select choice_id , description from ma_answer where question_id='".$q."'";
//$query = "select choice_id , description from ma_answer where question_id=1";
} else {
$query = "select ma_answer.choice_id choice_id,ma_answer.description description from ma_answer, ma_unit, ma_question  where ma_unit.question_id=ma_answer.question_id and ma_unit.unit_id='{$u}' and ma_unit.unit_rownum='{$q}' and ma_question.level_id='{$l}' and ma_question.question_id=ma_unit.question_id";
}
//echo "$query";

$result = mysqli_query ($connection, $query) or die ("Issue on retrieving data");
while ($row = mysqli_fetch_array ($result)) {
$choice_id= $row['choice_id'];
$description= $row['description'];
echo "<br>[$choice_id]: $description<br>";
//echo "<br><input type=\"radio\">  [$choice_id]: $description";
};

//Get Graph
if ($u == "F") {
$sql = "select question_id,graph_answer from ma_answer_graph where question_id='".$q."'";
} else {
$sql = "select ma_answer_graph.graph_answer from ma_answer_graph, ma_unit, ma_question  where ma_unit.question_id=ma_answer_graph.question_id and ma_unit.unit_id='{$u}' and ma_unit.unit_rownum='{$q}' and ma_question.level_id='{$l}' and ma_question.question_id=ma_unit.question_id";
}

if (!$result=mysqli_query($connection, $sql)){
echo mysqli_error($connection);
}
else {
$row = mysqli_fetch_array($result);
if ($row != null) {
echo '<img src="data:image/jpeg;base64,'.base64_encode($row['graph_answer']).'"/>';
}
}


mysqli_close($connection);
?>
