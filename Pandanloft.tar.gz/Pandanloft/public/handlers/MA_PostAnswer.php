<?php
include_once '../../private/common/initialization.php';
 
$u=$_POST["u"];
$q=$_POST["q"];
$l=$_POST["l"];

//$connection = mysqli_connect($HOST,$USER,$PASSWORD,$DATABASE) or die ("Issue on connecting mysql");
//$connection = mysqli_connect("localhost","test","test","Pandan01") or die ("Issue on connecting mysql");
$connection = $mysqli;

//Get answer
//$query = "select choice_id , description from ma_answer where question_id='".$q."'";
//$query = "select choice_id , description from ma_answer where question_id=1";

$query = "select ma_answer.choice_id choice_id,ma_answer.description description from ma_answer, ma_unit, ma_question  where ma_unit.question_id=ma_answer.question_id and ma_unit.unit_id='{$u}' and ma_unit.unit_rownum='{$q}' and ma_question.level_id='{$l}' and ma_question.question_id=ma_unit.question_id";

//echo "$query";

$result = mysqli_query ($connection, $query) or die ("Issue on retrieving data");
while ($row = mysqli_fetch_array ($result)) {
$choice_id= $row['choice_id'];
$description= $row['description'];
echo "<br>[$choice_id]: $description";
//echo "<br><input type=\"radio\">  [$choice_id]: $description";
};
mysqli_close($connection);
?>
