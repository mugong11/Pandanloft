<?php
include_once '../../private/common/initialization.php';
 

$connection = $mysqli;

$query = "select DATE_FORMAT(created_date,'%d/%m/%Y') created_date1,message from ta_news where posted=true order by created_date desc";
//echo "$query";

$result = mysqli_query ($connection, $query) or die ("Issue on retrieving data");
while ($row = mysqli_fetch_array ($result)) {
$created_date= $row['created_date1'];
$message= $row['message'];
echo "<br>[$created_date]: $message<br>";
};


mysqli_close($connection);
?>
