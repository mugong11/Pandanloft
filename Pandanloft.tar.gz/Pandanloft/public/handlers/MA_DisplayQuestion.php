<script>
$(document).ready(function(){
   $("#VerifyAnswer").click(function(){
   
<?php
$u=$_GET["u"];
$l=$_GET["l"];

echo "var var_u='$u';";
echo "var var_l='$l';";
?>
   
    var data1="jkkk";
//    alert("fms-1:"+data1);
    var e=document.getElementById("users");
    var value=e.options[e.selectedIndex].text;
    var value1='q=' + value;
    value1=value1+"&&u="+var_u+"&&l="+var_l;
           	console.log(value1);
    $.post("handlers/MA_PostAnswer.php",value1,function(data){
    	console.log(data);
//	alert("data is:"+ data);
	$("#answerhint").html(data);
        
    });
  });
});
</script>

<script type="text/javascript">
function showQuestion(str)
{

<?php
$u=$_GET["u"];
$l=$_GET["l"];
//echo "<script>console.log('u={$u}' );</script>";
//echo "<script>console.log('l={$l}' );</script>";

echo "var var_u='$u';";
echo "var var_l='$l';";
?>

console.log("showQuestion-input:"+str+","+var_u+","+var_l);  

if (str=="")
  {
  document.getElementById("txtHint").innerHTML="";
  return;
  } 	
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("GET","handlers/MA_GetQuestion.php?q="+str+"&&u="+var_u+"&&l="+var_l,true);
xmlhttp.send();

$("#answerhint").html('');
}
</script>

