<script>
$(document).ready(function(){
   $("#VerifyAnswer").click(function(){
   
<?php
$u=$_GET["u"];
$l=$_GET["l"];

echo "var var_u='$u';";
echo "var var_l='$l';";
?>
   
    var data1="jkkk";
//    alert("fms-1:"+data1);
    var e=document.getElementById("users");
    var value=e.options[e.selectedIndex].text;
    var value1='q=' + value;
    value1=value1+"&&u="+var_u+"&&l="+var_l;
           	console.log(value1);
    $.post("handlers/MA_PostAnswer.php",value1,function(data){
//    	console.log(data);
//	alert("data is:"+ data);
	$("#answerhint").html(data);
        
    });
  });

  $("#VerifyAnswerFull button").click(function(){
   
    var value1 = $(this).val();
    var hint = "#answerhint"+$(this).val();
    var hint1 = "answerhint"+$(this).val();
    value1="q="+value1+"&&u=F&&l=F";
//           	console.log(value1);
    $.post("handlers/MA_PostAnswer.php",value1,function(data){
//    	console.log(hint);
//	alert("data is:"+ data);
	$(hint).html(data);
    MathJax.Hub.Queue(['Typeset',MathJax.Hub, hint1]);  
        
    });
  });


});
</script>

<script type="text/javascript">
function showQuestion(str)
{

<?php
$u=$_GET["u"];
$l=$_GET["l"];
//echo "<script>console.log('u={$u}' );</script>";
//echo "<script>console.log('l={$l}' );</script>";

echo "var var_u='$u';";
echo "var var_l='$l';";
?>

console.log("showQuestion-input:"+str+","+var_u+","+var_l);  

if (str=="")
  {
  document.getElementById("txtHint").innerHTML="";
  return;
  } 	
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("GET","handlers/MA_GetQuestion.php?q="+str+"&&u="+var_u+"&&l="+var_l,true);
xmlhttp.send();

$("#answerhint").html('');
}

      function scrollFunction() {
        window.scrollTo(0, findPosition(document.getElementById("content")));
      }
      function findPosition(obj) {
        var currenttop = 0;
        if (obj.offsetParent) {
          do {
            currenttop += obj.offsetTop;
          } while ((obj = obj.offsetParent));
          return [currenttop];
        }
      }
      
// Get the button
let topbutton = document.getElementById("TopBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollTopFunction()};

function scrollTopFunction() {
  if (document.body.scrollTop > 200 || document.documentElement.scrollTop > 200) {
    topbutton.style.display = "block";
  } else {
    topbutton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}      
      
</script>

