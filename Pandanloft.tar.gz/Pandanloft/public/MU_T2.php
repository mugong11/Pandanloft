<?php
 $page_title = "L2 Music";
 include_once 'common/top.php';
?>

<?php
 $class = "MU_T1";
 $class_msg = "Music Theory (Level 2)";
// include_once 'common/leftnav.php';
 include_once 'common/dropdown.php';
?>
</article>

<?php
 include_once 'common/rightsidebar.php';
 include_once 'common/bottom.php';
?>

