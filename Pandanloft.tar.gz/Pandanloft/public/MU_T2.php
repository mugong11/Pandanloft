<?php
 $page_title = "L2";
 include_once 'common/top.php';
?>

<div>

</div>

<section>
<p>Welcome to Level 2 Music Theory Garden ! <br>
*Understructing and come soon
</p>
</section>

<?php
 include_once 'common/bottom.php';
?>

