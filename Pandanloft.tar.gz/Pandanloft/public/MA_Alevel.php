<?php
 include_once '../private/common/initialization.php';
 $page_title = "A_level Math";
 include_once 'common/top.php';
?>

<?php
    if(isset($_SESSION['username'])):
?>    
            <!-- This hidden form contains the values we need to read the data: log-id, data-verb, and token -->
             <form id="data-read-form" class="hidden">
                <input type="hidden" id="data-verb" name="data-verb" value="read-all-data">
                <input type="hidden" id="token" name="token" value="<?php echo $_SESSION['token']; ?>">
            </form>
            
            <!-- If there's an error reading the data, the error message appears inside this span -->
            <span id="read-error" class="error error-message"></span>

<?php
 $class = "MA_Alevel";
 $class_msg = "Mathemtics (A level)";
 include_once 'common/leftnav.php';
// include_once 'common/dropdown.php';
?>
</article>

<?php
    else:
?>

<?php
 endif;
 include_once 'common/rightsidebar.php';
 include_once 'common/bottom.php';
?>

