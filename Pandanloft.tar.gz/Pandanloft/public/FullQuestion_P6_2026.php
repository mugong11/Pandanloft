<?php
 include_once '../private/common/initialization.php';
?>

<?php
$l=$_GET["l"];

if ($l == 'MA_P6') {
 $page_title = "P6 Math";
 } elseif ($l == 'MA_P5') {
  $page_title = "P5 Math";
} elseif ($l == 'MA_Olevel'){
  $page_title = "O_level_Math";
} elseif ($l == 'MA_Alevel'){
  $page_title = "A_level_Math";
}
?>

<?php
$l=$_GET["l"];
$class = $l;
 
if ($l == 'MA_P6') {
 $class_msg = "Mathemtics (Primary 6)";
 } elseif  ($l == 'MA_P5'){
 $class_msg = "Mathemtics (Primary 5)";
}  elseif ($l == 'MA_Olevel'){
 $class_msg = "Mathemtics (O level)";
}  elseif ($l == 'MA_Alevel'){
 $class_msg = "Mathemtics (A level)";
}

 include_once 'common/top.php';
 include_once 'handlers/MA_DisplayQuestion.php';
 include_once 'common/leftnav.php';
?>

<?php
//showQuestsion("1");
// include_once 'handlers/MA_GetQuestion.php?q="+str+"&&u="+var_u+"&&l="+var_l,true);
// include 'handlers/MA_GetQuestion.php?q=1&&&u=1&&l=MA_P6';

//$u=$_GET["u"];
//$q=$_GET["q"];
$l=$_GET["l"];
$u="1";
$q="1";
//$l="MA_Olevel";
//echo "<script>console.log('u={$u}' );</script>";
//echo "<script>console.log('q={$q}' );</script>";
//echo "<script>console.log('q={$l}' );</script>";


//$connection = mysqli_connect($HOST,$USER,$PASSWORD,$DATABASE) or die ("Issue on connecting mysql");
$connection = $mysqli;
//$connection = mysqli_connect("localhost","test","test","Pandan01") or die ("Issue on connecting mysql");

//Get question
//$query="select question_id, description from ma_question where question_id='1'";
//$query="select question_id, description from ma_question where question_id='".$q."'";
//$query="select ma_question.question_id,ma_question.description from ma_question, ma_unit where ma_unit.question_id=ma_question.question_id and ma_unit.unit_id='{$u}' and ma_unit.unit_rownum='{$q}' and ma_question.level_id='{$l}'";
//$query="select row_number() over (order by ma_question.question_id desc) as question_id,ma_question.description, ma_question.question_id as id, ma_question.mark as mark from ma_question, ma_unit where ma_unit.question_id=ma_question.question_id and ma_question.level_id='{$l}'";
#$query="select row_number() over (order by ma_question.question_id desc) as question_id,ma_question.description, ma_question.question_id as id, ma_question.mark as mark from ma_question where 1=1 and ma_question.level_id='{$l}'";
$query="select row_number() over (order by ma_question.question_id asc) as question_id,ma_question.description, ma_question.question_id as id, ma_question.mark as mark, CONCAT(remark,'-',COALESCE(remark2,'')) as remark from ma_question where 1=1 and ma_question.level_id='{$l}' and ma_question.remark like '%2026_PRE'";

//echo "<script>console.log('{$query}');</script>";
//echo "<div>";
//echo "<table border='1'><tr><th>id</th><th>question</th><th>id2</th></tr>";

$result = mysqli_query ($connection, $query) or die ("Issue on retrieving data");

//echo "	<p>Question:</p>";

while ($row = mysqli_fetch_array ($result)) {
$question_id= $row['question_id'];
$description= $row['description'];
$mark= $row['mark'];
$remark=$row['remark'];
$id= $row['id'];
//echo "<tr><td>$question_id</td><td>$description</td><td>$id</td><tr>";

echo "<u><strong>Question $question_id [$mark][$remark]</strong></u><br>";
//echo "<u><strong>Question $question_id</strong></u><br>";
//echo "<u><strong>Question $question_id</strong></u>($id)<br>";
//echo "<u><strong>Question $question_id</strong></u><br>";
echo "$description<br>";

//Get Graph
$sql = "select question_id,graph_question from ma_question_graph where question_id='".$id."'";
if (!$result1=mysqli_query($connection, $sql)){
echo mysqli_error($connection);
}
else {
$row1 = mysqli_fetch_array($result1);
if ($row1 != null) {
echo '<img src="data:image/jpeg;base64,'.base64_encode($row1['graph_question']).'"/>';
echo "<br>";
}
}

//echo "</td></tr>";

//Get choice
$query2 = "select ma_choice.choice_id c_id,ma_choice.description c_d from ma_question, ma_choice where ma_question.question_id=ma_choice.question_id and ma_question.question_id='".$id."' order by choice_id";

$result2 = mysqli_query ($connection, $query2) or die ("Issue on retrieving data");
$row2 = mysqli_fetch_array ($result2);
if ($row2 != null) {
echo "<br>choose one of answer:<br>";
echo "<ol>";
$choice_id= $row2['c_id'];
$description= $row2['c_d'];
echo "<li>$description</li>";

while ($row2 = mysqli_fetch_array ($result2)) {
$choice_id= $row2['c_id'];
$description= $row2['c_d'];
echo "<li>$description</li>";
};
echo "</ol><br>";
}
else {
echo "<br>Write the answer:____________________<br><br>";
};
echo "<div id=\"VerifyAnswerFull\" ><button value=\"$id\" >Verify Answer</button></div>";
//echo "<button id=\"VerifyAnswerFull\">Verify Answer</button>";
echo "<div id=\"answerhint$id\"> <p>...</p></div>";
echo "<br><br>";
};


//echo "</table>";
mysqli_close($connection);

?>
</div>

<button onclick="topFunction()" id="TopBtn" title="Go to top">Top</button>
</article>

<script>
scrollFunction();
</script>

<?php
 include_once 'common/rightsidebar.php';
 include_once 'common/bottom.php';
?>

