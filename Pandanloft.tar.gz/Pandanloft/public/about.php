<?php
 include_once '../private/common/initialization.php';
 $page_title = "About";
 include_once 'common/top.php';
?>

<?php
    if(isset($_SESSION['username'])):
?>    
            <!-- This hidden form contains the values we need to read the data: log-id, data-verb, and token -->
             <form id="data-read-form" class="hidden">
                <input type="hidden" id="data-verb" name="data-verb" value="read-all-data">
                <input type="hidden" id="token" name="token" value="<?php echo $_SESSION['token']; ?>">
            </form>
            
            <!-- If there's an error reading the data, the error message appears inside this span -->
            <span id="read-error" class="error error-message"></span>

<section>
<article>
<p>Welcome to Pandanloft Enrichment Garden ! <br><br>
We provide the below learning services, <br><br>
- Primary Mathematics from Primary 5 to 6  <br>
<!-- - Music Theory from Level 1 to 5  -->
<br><br>

for customer service,<a href = "mailto: Pandanloft.enrichment@gmail.com">please contact with email</a>

</p>
<img src="images/MOE_P5.jpg">
<img src="images/MOE_P6.jpg">

<p>
<a href="http://pandanloft.blogspot.com" target="_blank"><strong>Click here for more stories ... </strong></a> <br><br>
<iframe width="30%" height="30%" src="https://www.youtube.com/embed/4DfZlORz0uw?controls=0">
</iframe>
<iframe width="30%" height="30%" src="https://www.youtube.com/embed/9YNvBdAuiXc?controls=0">
</iframe>
<iframe width="30%" height="30%" src="https://www.youtube.com/embed/nQqPyLcmuyo?controls=0">
</iframe>
</p>
</article>

<?php
    else:
?>

<section>
<article>
<p>Welcome to Pandanloft Enrichment Garden ! <br><br>
We provide the below learning services, <br><br>
- Primary Mathematics from Primary 5 to 6  <br>
<!-- - Music Theory from Level 1 to 5  -->
<br><br>

for customer service,<a href = "mailto: Pandanloft.enrichment@gmail.com">please contact with email</a>

</p>
<img src="images/MOE_P5.jpg">
<img src="images/MOE_P6.jpg">

<p>
<a href="http://pandanloft.blogspot.com" target="_blank"><strong>Click here for more stories ... </strong></a> <br><br>
<iframe width="30%" height="30%" src="https://www.youtube.com/embed/4DfZlORz0uw?controls=0">
</iframe>
<iframe width="30%" height="30%" src="https://www.youtube.com/embed/9YNvBdAuiXc?controls=0">
</iframe>
<iframe width="30%" height="30%" src="https://www.youtube.com/embed/nQqPyLcmuyo?controls=0">
</iframe>
</p>
</article>

<?php
 endif;
 include_once 'common/rightsidebar.php';
 include_once 'common/bottom.php';
?>

