<?php
 $page_title = "About";
 include_once 'common/top.php';
?>

<div>

</div>

<section>
<article>
<p>Welcome to Pandanloft Enrichment Garden ! <br><br>
We provide the below learning services, <br><br>
- Primary Mathematics from Primary 1 to 6  <br>
- Music Theory from Level 1 to 5  <br><br>

for customer service,<a href = "mailto: Pandanloft.enrichment@gmail.com">please contact with email</a>

</p>
</article>

<?php
 include_once 'common/rightsidebar.php';
 include_once 'common/bottom.php';
?>

