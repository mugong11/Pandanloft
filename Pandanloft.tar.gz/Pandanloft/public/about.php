<?php
 include_once '../private/common/initialization.php';
 $page_title = "About";
 include_once 'common/top.php';
?>

<?php
    if(isset($_SESSION['username'])):
?>    
            <!-- This hidden form contains the values we need to read the data: log-id, data-verb, and token -->
             <form id="data-read-form" class="hidden">
                <input type="hidden" id="data-verb" name="data-verb" value="read-all-data">
                <input type="hidden" id="token" name="token" value="<?php echo $_SESSION['token']; ?>">
            </form>
            
            <!-- If there's an error reading the data, the error message appears inside this span -->
            <span id="read-error" class="error error-message"></span>

<section>
<article>
<p>Welcome to Pandanloft Enrichment Garden ! </p><br><br>

Welcome to our esteemed Mathematics Enrichment website, a dedicated platform meticulously designed to guide Singapore Primary students toward mathematical excellence. With an unwavering commitment to your academic success, we proudly present a comprehensive collection of practice questions and answers, meticulously tailored to align harmoniously with the curriculum set by the Singapore education authorities.<br><br>

At the core of our service lies an unswerving dedication to providing an unparalleled learning experience. We offer an extensive repository of practice questions, thoughtfully categorized to address the diverse facets of your mathematical journey. Our commitment to structured and strategic learning is embodied in the careful grouping of questions based on difficulty levels and curriculum subjects.<br><br>

Embracing the diverse learning styles and needs of our students, we present questions that span a gamut of complexity. Whether you seek to solidify foundational concepts or master advanced problem-solving, our categorization ensures a learning trajectory that perfectly aligns with your unique goals.<br><br>

Our commitment to the esteemed curriculum is evident in every facet of our offering. Each question is meticulously designed to encapsulate the essence of the syllabus, facilitating a seamless transition between classroom learning and autonomous practice. Beyond being exercises, our questions serve as gateways to consolidate theoretical knowledge, amplify analytical thinking, and nurture a genuine understanding of mathematical principles.<br><br>

We understand that assessments are pivotal for growth. As such, each question is accompanied by detailed, step-by-step solutions that guide you through the problem-solving process. These solutions are complemented by visually engaging diagrams that enhance comprehension and illuminate the path to mastery.<br><br>

Our comprehensive curriculum spans the following subjects:<br>

- Whole Numbers<br>
- Decimals<br>
- Fractions<br>
- Percentage<br>
- Ratio<br>
- Rate and Speed<br>
- Algebra<br>
- Geometry<br>
- Statistics<br>
- Logic<br>
<br><br>
Whether your aim is to excel in examinations, master mathematical concepts, or elevate your problem-solving prowess, our Mathematics Enrichment website is your steadfast companion on this journey. Embrace the transformative power of practice, elevate your understanding, and embark on a voyage of mathematical achievement with us. Your path to mathematical excellence starts here.
<br><br>

for customer service,<a href = "mailto: Pandanloft.enrichment@gmail.com">please contact with email</a>

</p>
<img src="images/MOE_P5.jpg">
<img src="images/MOE_P6.jpg">

<p>
<a href="http://pandanloft.blogspot.com" target="_blank"><strong>Click here for more stories ... </strong></a> <br><br>
<iframe width="30%" height="30%" src="https://www.youtube.com/embed/4DfZlORz0uw?controls=0">
</iframe>
<iframe width="30%" height="30%" src="https://www.youtube.com/embed/9YNvBdAuiXc?controls=0">
</iframe>
<iframe width="30%" height="30%" src="https://www.youtube.com/embed/nQqPyLcmuyo?controls=0">
</iframe>
</p>
</article>

<?php
    else:
?>

<section>
<article>
<p>Welcome to Pandanloft Enrichment Garden ! <br><br>
We provide the below learning services, <br><br>
- Primary Mathematics from Primary 5 to 6  <br>
<!-- - Music Theory from Level 1 to 5  -->
<br><br>

for customer service,<a href = "mailto: Pandanloft.enrichment@gmail.com">please contact with email</a>

</p>
<img src="images/MOE_P5.jpg">
<img src="images/MOE_P6.jpg">

<p>
<a href="http://pandanloft.blogspot.com" target="_blank"><strong>Click here for more stories ... </strong></a> <br><br>
<iframe width="30%" height="30%" src="https://www.youtube.com/embed/4DfZlORz0uw?controls=0">
</iframe>
<iframe width="30%" height="30%" src="https://www.youtube.com/embed/9YNvBdAuiXc?controls=0">
</iframe>
<iframe width="30%" height="30%" src="https://www.youtube.com/embed/nQqPyLcmuyo?controls=0">
</iframe>
</p>
</article>

<?php
 endif;
 include_once 'common/rightsidebar.php';
 include_once 'common/bottom.php';
?>

