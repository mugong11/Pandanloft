<?php
 $page_title = "P6 Math";
 include_once 'common/top.php';
?>

<section>
  <nav>
    <ul>
      <li><a href="./MA_P6_SelectQuestion.php?u=1&&l=P6">Unit 1</a></li>
      <li><a href="./MA_P6_SelectQuestion.php?u=2&&l=P6">Unit 2</a></li>
      <li><a href="./MA_P6_SelectQuestion.php?u=3&&l=P6">Unit 3</a></li>
      <li><a href="./MA_P6_SelectQuestion.php?u=4&&l=P6">Unit 4</a></li>
      <li><a href="./MA_P6_SelectQuestion.php?u=5&&l=P6">Unit 5</a></li>
      <li><a href="./MA_P6_SelectQuestion.php?u=6&&l=P6">Unit 6</a></li>
      <li><a href="./MA_P6_SelectQuestion.php?u=7&&l=P6">Unit 7</a></li>
      <li><a href="./MA_P6_SelectQuestion.php?u=8&&l=P6">Unit 8</a></li>
     </ul>
  </nav>

<article>
<div>
Welcome to Primary 6 Mathematics Garden !
</div>
</article>

<?php
 include_once 'common/bottom.php';
?>

