<?php
 $page_title = "L1";
 include_once 'common/top.php';
?>

<div>

</div>

<section>
<p>Welcome to Level 1 Music Theory Garden ! <br>
*Understructing and come soon
</p>
</section>

<?php
 include_once 'common/bottom.php';
?>

