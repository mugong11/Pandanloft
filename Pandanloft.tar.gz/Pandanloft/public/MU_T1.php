<?php
 $page_title = "L1 Music";
 include_once 'common/top.php';
?>

<?php
 $class = "MU_T1";
 $class_msg = "Music Theory (Level 1)";
 include_once 'common/leftnav.php';
?>
</article>

<?php
 include_once 'common/rightsidebar.php';
 include_once 'common/bottom.php';
?>

