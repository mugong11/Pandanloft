<?php
    include_once '../private/common/initialization.php';
    $page_title = 'Your Pandanloft! Account';
    include_once 'common/top.php';

    // Is the user signed in?
    if(isset($_SESSION['username'])):
        

?>
            <p>
                <strong>Your Pandanloft! username:</strong><br>
                <?php echo $_SESSION['username'] ?>
            </p>
                        <p>
                Here are the tasks you can perform with your account:
            <p>
                <a href="request_new_password.php">Change Your Password</a>
            </p>
            <p>
                <a href="sign_out.php">Sign Out</a>
            </p>

<?php
    else:
?>
        <!-- Display the sign-in page -->
        <meta http-equiv="refresh" content="0;sign_in.php">
<?php
    endif;
    include_once 'common/sidebar.php';
    include_once 'common/bottom.php';
?>
