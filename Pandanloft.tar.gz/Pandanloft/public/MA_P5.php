<?php
 $page_title = "P5 Math";
 include_once 'common/top.php';
?>

<?php
 $class = "MA_P5";
 $class_msg = "Mathemtics (Primary 5)";
 include_once 'common/leftnav.php';
?>

<?php
 include_once 'common/bottom.php';
?>

