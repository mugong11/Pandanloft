<?php
 $page_title = "L1 Music";
 include_once 'common/top.php';
 include_once 'handlers/MA_DisplayQuestion.php'
?>

<?php
 $class = "MU_T2";
 $class_msg = "Music Theory (Level 2)";
 include_once 'common/leftnav.php';
?>

<?php
 include_once 'common/questionbox.php';
?>

<?php
 include_once 'common/rightsidebar.php';
 include_once 'common/bottom.php';
?>


