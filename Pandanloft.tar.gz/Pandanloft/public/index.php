<?php
 include_once '../private/common/initialization.php';
 $page_title='Home';
 include_once 'common/top.php';
?>

<section>
<p>Welcome to Pandaloft Enrichment Garden !</p>
</section>

<?php
 include_once 'common/bottom.php';
?>

