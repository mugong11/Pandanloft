<?php
 include_once '../private/common/initialization.php';
 $page_title='Home';
 include_once 'common/top.php';
?>

<?php
    if(isset($_SESSION['username'])):
?>    
            <!-- This hidden form contains the values we need to read the data: log-id, data-verb, and token -->
             <form id="data-read-form" class="hidden">
                <input type="hidden" id="data-verb" name="data-verb" value="read-all-data">
                <input type="hidden" id="token" name="token" value="<?php echo $_SESSION['token']; ?>">
            </form>
            
            <!-- If there's an error reading the data, the error message appears inside this span -->
            <span id="read-error" class="error error-message"></span>

<p>Lastest Update</p>
<?php
 include_once './handlers/MA_DislayMessage.php';
?>


<?php
    else:
?>

<section>
<article>
<p>Welcome to Pandanloft Enrichment Garden !</p>

<em>No human investigation can be called real science if it cannot be demonstrated mathematically.</em><br>
— <strong>Leonardo Da Vinci</strong>
<br><br>
<em>God does arithmetic. </em><br>
— <strong>Karl Friedrich Gauss</strong>
<br><br>
<em>Pure mathematics is, in its way, the poetry of logical ideas.</em><br>
— <strong>Albert Einstein</strong>
<br><br>
<p>
Mathematics - Junior-College / Pre-University / A-level <br><br>
<img src="images/MOE_JC.jpg">
<ul>
<li>PURE MATHEMATICS</li>
<ul>
<li>Functions and Graphs</li>
<ul>
<li>Functions
<li>Graphs and transformations
<li>Equations and inequalities
</ul>
<li>Sequences and Series</li>
<ul>
<li>Sequences and series</li>
</ul>
<li>Vectors</li>
<ul>
<li>Basic properties of vectors in two- and three-dimensions</li>
<li>Scalar and vector products in vectors</li>
<li>Three-dimensional vector geometry </li>
</ul>
<li>Introduction to Complex Numbers</li>
<ul>
<li>Complex numbers expressed in Cartesian form and Argand diagrams</li>
<li>Complex numbers expressed in polar form</li>
</ul>
<li>Calculus</li>
<ul>
<li>Differentiation</li>
<li>Maclaurin series</li>
<li>Integration techniques</li>
<li>Definite integrals</li>
<li>Differential equations</li>
</ul>
<li>O-level Additional Math</li>
<ul>
<li>Quadratic functions</li>
<li>Equations and inequalities</li>
<li>Surds</li>
<li>Polynomials and partial fractions</li>
<li>Exponential and logarithmic functions</li>
<li>Trigonometric functions, identities and equations</li>
<li>Coordinate geometry in two dimensions</li>
<li>Differentiation and integration</li>
</ul>
</ul>
<li>PROBABILITY AND STATISTICS</li>
<ul>
<li>Probability and Statistics</li>
<ul>
<li>Probability</li>
<li>Discrete random variables</li>
<li>Normal distribution</li>
<li>Sampling</li>
<li>Hypothesis testing</li>
<li>Correlation and Linear regression</li>
</ul>
</ul>
</ul>
</ul>
</p>
<br><br><br>
<p>
Mathematics - Secondary / O-level <br><br>
<img src="images/MOE_Sec.jpg">
<ul>
<li>NUMBER AND ALGEBRA</li>
<ul>
<li>Numbers and their operations</li>
<li>Ratio and proportion</li>
<li>Percentage</li>
<li>Rate and Speed</li>
<li>Algebraic expressions and formulate</li>
<li>Functions and graphs</li>
<li>Equations and inequalities</li>
<li>Set language and notation</li>
<li>Matrices</li>
</ul>
</ul>
<ul>
<li>GEOMETRY AND MEASUREMENT</li>
<ul>
<li>Angles, triangles and polygons</li>
<li>Congruence and similarity</li>
<li>Properties of circles</li>
<li>Pythagoras’ theorem and trigonometry</li>
<li>Mensuration</li>
<li>Coordinate geometry</li>
<li>Vectors in two dimensions</li>
</ul>
</ul>
<ul>
<li>STATISTICS AND PROBABILITY</li>
<ul>
<li>Data handling and analysis</li>
<li>Probability</li>
</ul>
</ul>
<ul>
<li>ALGEBRA (Additional Math)</li>
<ul>
<li>Quadratic functions</li>
<li>Equations and inequalities</li>
<li>Surds</li>
<li>Polynomials and partial fractions</li>
<li>Binomial expansions</li>
<li>Exponential and logarithmic functions</li>
</ul>
</ul>
<ul>
<li>GEOMETRY AND TRIGONOMETRY (Additional Math)</li>
<ul>
<li>Trigonometric functions, identities and equations</li>
<li>Coordinate geometry in two dimensions</li>
<li>Proofs in plane geometry</li>
</ul>
</ul>
<ul>
<li>CALCULUS (Additional Math)</li>
<ul>
<li>Differentiation and integration</li>
</ul>
</ul>
</p>
<br><br><br>
<p>
Mathematics - Primary 6 <br><br>
<img src="images/MOE_P6.jpg">
<ul>
<li>NUMBER AND ALGEBRA</li>
<ul>
<li>FRACTIONS</li>
<ul>
<li>Four Operations</li>
</ul>
<li>PERCENTAGE</li>
<ul>
<li>Percentage</li>
</ul>
<li>RATIO</li>
<ul>
<li>Ratio</li>
</ul>
<li>RATE AND SPEED</li>
<ul>
<li>Distance, Time and Speed</li>
</ul>
<li>ALGEBRA</li>
<ul>
<li>Algebra</li>
</ul>
</ul>
<li>MEASUREMENT AND GEOMETRY</li>
<ul>
<li>AREA AND VOLUME</li>
<ul>
<li>Area and Circumference of Circle</li>
<li>Volume of Cube and Cuboid</li>
</ul>
<li>GEOMETRY</li>
<ul>
<li>Special Quadrilaterals</li>
<li>Nets</li>
</ul>
</ul>
<li>STATISTICS</li>
<ul>
<li>DATA REPRESENTATION AND INTERPRETATION</li>
<ul>
<li>Pie Charts</li>
</ul>
</ul>
</ul>
</p>

<br><br>
<p>
Mathematics - Primary 5 <br><br>
<img src="images/MOE_P5.jpg">

<ul>
<li>NUMBER AND ALGEBRA</li>
<ul>
<li>WHOLE NUMBERS</li>
<ul>
<li>Numbers up to 10 million</li>
<li>Four Operations</li>
</ul>
<li>FRACTIONS</li>
<ul>
<li>Fraction and Division</li>
<li>Four Operations</li>
</ul>
<li>DECIMALS</li>
<ul>
<li>Four Operations</li>
</ul>
<li>PERCENTAGE</li>
<ul>
<li>Percentage</li>
</ul>
<li>RATIO</li>
<ul>
<li>Ratio</li>
</ul>
<li>RATE AND SPEED</li>
<ul>
<li>Rate</li>
</ul>
</ul>
<li>MEASUREMENT AND GEOMETRY</li>
<ul>
<li>AREA AND VOLUME</li>
<ul>
<li>Area of Triangle</li>
<li>Volume of Cube and Cuboid</li>
</ul>
<li>GEOMETRY</li>
<ul>
<li>Angles</li>
<li>Triangle</li>
<li>Parallelogram, Rhombus and Trapezium</li>
</ul>
</ul>
<li>STATISTICS</li>
<ul>
<li>DATA ANALYSIS</li>
<ul>
<li>Average of a Set of Data</li>
</ul>
</ul>
</ul>


</p>
</article>

<?php
 endif;
 include_once 'common/rightsidebar.php';
 include_once 'common/bottom.php';
?>

