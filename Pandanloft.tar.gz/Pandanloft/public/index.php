<?php
 include_once '../private/common/initialization.php';
 $page_title='Home';
 include_once 'common/top.php';
?>

<article>
<section>
<p>Welcome to Pandanloft Enrichment Garden !</p>
</section>
</article>
<?php
 include_once 'common/sidebar.php';
 include_once 'common/bottom.php';
?>

