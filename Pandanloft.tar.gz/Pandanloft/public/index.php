<?php
 include_once '../private/common/initialization.php';
 $page_title='Home';
 include_once 'common/top.php';
?>

<section>
<article>
<p>Welcome to Pandanloft Enrichment Garden !</p>

<em>No human investigation can be called real science if it cannot be demonstrated mathematically.</em><br>
— <strong>Leonardo Da Vinci</strong>
<br><br>
<em>God does arithmetic. </em><br>
— <strong>Karl Friedrich Gauss</strong>
<br><br>
<em>Pure mathematics is, in its way, the poetry of logical ideas.</em><br>
— <strong>Albert Einstein</strong>
<br><br>

<p>Lastest Update</p>
<?php
 include_once './handlers/MA_DislayMessage.php';
?>

<br>
<p>
Mathematics - Primary 6 <br><br>
<img src="images/MOE_P6.jpg">
<ul>
<li>NUMBER AND ALGEBRA</li>
<ul>
<li>FRACTIONS</li>
<ul>
<li>Four Operations</li>
</ul>
<li>PERCENTAGE</li>
<ul>
<li>Percentage</li>
</ul>
<li>RATIO</li>
<ul>
<li>Ratio</li>
</ul>
<li>RATE AND SPEED</li>
<ul>
<li>Distance, Time and Speed</li>
</ul>
<li>ALGEBRA</li>
<ul>
<li>Algebra</li>
</ul>
</ul>
<li>MEASUREMENT AND GEOMETRY</li>
<ul>
<li>AREA AND VOLUME</li>
<ul>
<li>Area and Circumference of Circle</li>
<li>Volume of Cube and Cuboid</li>
</ul>
<li>GEOMETRY</li>
<ul>
<li>Special Quadrilaterals</li>
<li>Nets</li>
</ul>
</ul>
<li>STATISTICS</li>
<ul>
<li>DATA REPRESENTATION AND INTERPRETATION</li>
<ul>
<li>Pie Charts</li>
</ul>
</ul>
</ul>
</p>

<br><br>
<p>
Mathematics - Primary 5 <br><br>
<img src="images/MOE_P5.jpg">

<ul>
<li>NUMBER AND ALGEBRA</li>
<ul>
<li>WHOLE NUMBERS</li>
<ul>
<li>Numbers up to 10 million</li>
<li>Four Operations</li>
</ul>
<li>FRACTIONS</li>
<ul>
<li>Fraction and Division</li>
<li>Four Operations</li>
</ul>
<li>DECIMALS</li>
<ul>
<li>Four Operations</li>
</ul>
<li>PERCENTAGE</li>
<ul>
<li>Percentage</li>
</ul>
<li>RATIO</li>
<ul>
<li>Ratio</li>
</ul>
<li>RATE AND SPEED</li>
<ul>
<li>Rate</li>
</ul>
</ul>
<li>MEASUREMENT AND GEOMETRY</li>
<ul>
<li>AREA AND VOLUME</li>
<ul>
<li>Area of Triangle</li>
<li>Volume of Cube and Cuboid</li>
</ul>
<li>GEOMETRY</li>
<ul>
<li>Angles</li>
<li>Triangle</li>
<li>Parallelogram, Rhombus and Trapezium</li>
</ul>
</ul>
<li>STATISTICS</li>
<ul>
<li>DATA ANALYSIS</li>
<ul>
<li>Average of a Set of Data</li>
</ul>
</ul>
</ul>


</p>
</article>

<?php
 include_once 'common/rightsidebar.php';
 include_once 'common/bottom.php';
?>

