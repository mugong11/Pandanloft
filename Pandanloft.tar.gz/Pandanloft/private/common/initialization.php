<?php

    // Include the app constants
    include_once 'constants.php';
 
    // Connect to the database
    $mysqli = new MySQLi(HOST, USER, PASSWORD, DATABASE);

    // Check for an error
    if($mysqli->connect_error) {
        echo 'Connection Failed! 
              Error #' . $mysqli->connect_errno
                . ': ' . $mysqli->connect_error;
        exit(0);
    }


?>
