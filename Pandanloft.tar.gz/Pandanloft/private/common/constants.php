<?php
 define('HOST','localhost');
 define('USER','test');
 define('PASSWORD','test');
 define('DATABASE','Pandan01');  
?>
