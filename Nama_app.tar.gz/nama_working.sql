/*Daily input
1.Download file sgx
2.add header TRADE DATE;STOCK NAME;REMARKS;CURRENCY;HIGH;LOW;LAST;CHANGE1;VOLUME;BID;OFFER;MARKET;OPEN;VALUE;STOCK CODE;DClose;
3.Load_sgx.py < l_p.sh, > sgx_daily_working
*/

/*Daily moving
1.
sgx_daily_working > sgx_daily_moving
*/
CALL `Nama01`.`test1`();
CALL `Nama01`.`LDR`();

/*Daily check-out
1. Last > MA5 > MA10 > MA20, Golden cross
2. MA20 > MA10 > MA5 > Last,  Dead cross
3. Volume up
*/
select * from sgx_daily_working where stock_code in ('P8Z') order by TRADE_DATE desc;
select * from sgx_daily_moving where stock_code in (' D05','Z2AB',' U11',' O39') order by stock_code,TRADE_DATE desc;
select count(1) from sgx_daily_working where TRADE_DATE='2024-10-10';
select count(1) from sgx_daily_moving;
select count(1) from sgx_daily_moving where ma5 is null;
select count(1) from sgx_daily_moving where ma5 is not null;
SELECT count(1) FROM sgx_daily_moving WHERE TRADE_DATE = '2024-10-09' and LDR is null;
SELECT * FROM sgx_daily_moving WHERE TRADE_DATE = '2024-10-10' ;
SELECT * FROM sgx_daily_moving WHERE STOCK_CODE='D05' order by trade_date desc;
select * from sgx_job;
SELECT stock_code,trade_date FROM sgx_daily_moving where trade_date>
    (select last_run_date from sgx_job where job_id='SGX_DAILY_MOVING');
update sgx_job set last_run_datest1te='2024-10-09' where job_id='SGX_DAILY_MOVING';
select max(TRADE_DATE) from sgx_daily_moving where stock_code in ('D05');
update sgx_job set last_run_date=(select max(TRADE_DATE) from sgx_daily_moving where stock_code in ('D05')) where job_id='SGX_DAILY_MOVING';

select * from sgx_daily_working where TRADE_DATE>='2024-05-24' and stock_code like '%U';
select * from sgx_daily_working where TRADE_DATE>='2024-05-24' and lower(stock_name) like 'csop%';
SELECT * FROM sgx_daily_moving where 1=1 and stock_code='D05';

select count(1) from sgx_daily_moving where trade_date='2024-10-09';
select count(1) from sgx_daily_working where trade_date='2024-10-09';
delete from sgx_daily_moving where trade_date='2024-10-09';
delete from sgx_daily_working where trade_date='2024-10-09';
delete from sgx_daily_moving where trade_date>='2024-04-08' and ma5 is null;

/**********************/
select * from sgx_daily_moving where ma5>ma10 and ma10>=ma20 and ma20>=ma50 and VOLUME>=10000 and stock_code not like '%W'  and TRADE_DATE=(select last_run_date from sgx_job) order by volume desc ;
select * from sgx_daily_moving where ma5>ma10 and ma10>=ma20 and ma20>=ma50 and TRADE_DATE='2024-08-08' and VOLUME>=10000 and stock_code not like '%W' order by volume desc ;
select count(1) from sgx_daily_moving where last>=ma5 and ma5>=ma10 and ma10>=ma20 and TRADE_DATE='2024-05-03' and VOLUME>=1000000 ;
select * from sgx_daily_moving where ma5>ma10 and ma10>=ma20 and ma20>=ma50 and TRADE_DATE='2024-06-25' and VOLUME>=10000 and last between 0.5 and 1 and stock_code not like '%W' order by VOLUME desc;
select * from sgx_daily_moving where ma5>ma10 and ma10>=ma20 and ma20>=ma50 and TRADE_DATE='2024-06-25' and VOLUME>=10000 and last between 0.1 and 0.5 and stock_code not like '%W'
union
select * from sgx_daily_moving where ma5>ma10 and ma10>ma20 and TRADE_DATE='2024-04-09' and VOLUME>=10000 and last between 1 and 2  and stock_code not like '%W'
union
select * from sgx_daily_moving where ma5>ma10 and ma10>ma20 and TRADE_DATE='2024-04-09' and VOLUME>=10000 and last >2  and stock_code not like '%W';

select * from sgx_daily_moving where last<=ma5 and ma5<=ma10 and ma10<=ma20 and TRADE_DATE='2024-04-02' and VOLUME>0 ;
select count(1) from sgx_daily_moving where last<=ma5 and ma5<=ma10 and ma10<=ma20 and TRADE_DATE='2024-04-02' and VOLUME>0 ;

/**********************/
/*LDR， =STDEV.P(M2:M146) =AVERAGE(M2:M146)*/
select * from sgx_daily_moving where stock_code in ('GSD') order by stock_code,TRADE_DATE desc;
select stock_code, FORMAT(avg(LDR)*count(1),2) ret,stddev(ldr)*sqrt(count(1)) std,count(1), avg(LDR)*count(1)/(stddev(ldr)*sqrt(count(1))) as s_ratio from sgx_daily_moving 
where ldr is not null
group by stock_code
/*having stock_code in ('U11','D05','O39')*/
having stock_code not like '%W' and s_ratio>0
order by s_ratio desc;

select * from 
(select stock_code, FORMAT(avg(LDR)*count(1),2) ret,FORMAT(stddev(ldr)*sqrt(count(1)),2) std,count(1), FORMAT(avg(LDR)*count(1)/(stddev(ldr)*sqrt(count(1))),2) as s_ratio from sgx_daily_moving 
where ldr is not null
group by stock_code
/*having stock_code in ('U11','D05','O39')*/
having stock_code not like '%W' and s_ratio>0
) t1, sgx_daily_moving s
where t1.stock_code = s.STOCK_CODE
and s.TRADE_DATE=(select last_run_date from sgx_job where job_id='SGX_DAILY_MOVING') 
/*and s.last <=0.50 and s.last>=0.20*/
and ma5>ma10 and ma10>=ma20 
and ma20>=ma50 and VOLUME>=10000
;

select log(31.93/31.76)*100 from dual;

/*Z2AB*/
select * from sgx_daily_moving where stock_code in ('Z1AB') order by stock_code,TRADE_DATE desc;
SELECT (1+DATEDIFF(sysdate(), "2024-07-22")/183*0.0317);
SELECT DATEDIFF(sysdate(), "2024-07-22")/183*0.0317;
SELECT 1.0317*1.35;

/*Housekeeping*/
delete from sgx_daily_working;

/*Backup*/
drop table sgx_daily_moving;
CREATE TABLE sgx_daily_moving (
    TRADE_DATE DATE,
    STOCK_NAME VARCHAR(30),
    LAST DECIMAL(7, 2),
    VOLUME INT(10),
    STOCK_CODE CHAR(4),
    MA5  DECIMAL(7, 2) null,
    MA10  DECIMAL(7, 2)  null,
    MA20  DECIMAL(7, 2)  null
);

drop table sgx_job;
create table sgx_job (
 job_id varchar(40),
 last_run_date date
);

insert sgx_job values ('SGX_DAILY_MOVING','2024-04-09');

CALL `Nama01`.`test1`();

select date(sysdate()-1) from dual;
SELECT * FROM sgx_daily_moving
where TRADE_DATE='2024-04-05' and stock_code='D05'
#INTO OUTFILE '~/mingsong2023/Proj_Nama/sgx_daily_moving.csv'
INTO OUTFILE '/tmp/sgx_daily_moving.csv'
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n';

/************************************/
/*sgx_monthly_screen*/
delete from sgx_monthly_screen;
select * from sgx_monthly_screen where STOCK_CODE='D05';
select * from sgx_monthly_screen
where pe>0 and pe<=12
and yield>=5
and 1yrrevchg+NetProfit>=40
;

select * from 
(select stock_code, FORMAT(avg(LDR)*count(1),2) ret,FORMAT(stddev(ldr)*sqrt(count(1)),2) std,count(1), FORMAT(avg(LDR)*count(1)/(stddev(ldr)*sqrt(count(1))),2) as s_ratio from sgx_daily_moving 
where ldr is not null
group by stock_code
/*having stock_code in ('U11','D05','O39')*/
having stock_code not like '%W' and s_ratio>0
) t1, sgx_daily_moving s, sgx_monthly_screen_history s2
where t1.stock_code = s.STOCK_CODE
and pe>0 and pe<=12 and yield>=5 and 1yrrevchg+NetProfit>=40
and s2.STOCK_CODE=s.STOCK_CODE
and s.TRADE_DATE=(select last_run_date from sgx_job where job_id='SGX_DAILY_MOVING') 
and s2.rec_date=(select last_run_date from sgx_job where job_id='SGX_MONTHLY_SCREEN') 
;

select STOCK_NAME,STOCK_CODE,LastPrice,ROE,MktCap,TotRev,PE,Yield,Sector,GTIScore,4wkPrChg,13wkPrChg,26wkPrChg,52wkPrChg,NetProfit,DebtEquity,1yrRevChg, last_run_date from sgx_monthly_screen,sgx_job where job_id='SGX_MONTHLY_SCREEN';
select * from sgx_monthly_screen_history where stock_code='D05';

select * from 
(select stock_code, FORMAT(avg(LDR)*count(1),2) ret,FORMAT(stddev(ldr)*sqrt(count(1)),2) std,count(1), FORMAT(avg(LDR)*count(1)/(stddev(ldr)*sqrt(count(1))),2) as s_ratio from sgx_daily_moving 
where ldr is not null
group by stock_code
/*having stock_code in ('U11','D05','O39')*/
having stock_code not like '%W' and s_ratio>0
) t1, sgx_daily_moving s, sgx_monthly_screen_history s2
where t1.stock_code = s.STOCK_CODE
and s.TRADE_DATE=(select last_run_date from sgx_job where job_id='SGX_DAILY_MOVING') 
/*and s.last <=0.50 and s.last>=0.20*/
and ma5>ma10 and ma10>=ma20 
and ma20>=ma50 and VOLUME>=10000
and s.STOCK_CODE=s2.stock_code
and s2.rec_date=(select last_run_date from sgx_job where job_id='SGX_MONTHLY_SCREEN') 
;
