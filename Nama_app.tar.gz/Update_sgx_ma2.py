import mysql.connector
import pandas as pd

# Function to establish a connection to MySQL database
def create_db_connection(host_name, user_name, user_password, db_name):
    connection = None
    try:
        connection = mysql.connector.connect(
            host=host_name,
            user=user_name,
            passwd=user_password,
            database=db_name
        )
        print("MySQL Database connection successful")
    except mysql.connector.Error as err:
        print(f"Error: '{err}'")

    return connection

# Function to execute SQL queries
def execute_query(connection, query):
    cursor = connection.cursor()
    try:
        cursor.execute(query)
        connection.commit()
        print("Query executed successfully")
    except mysql.connector.Error as err:
        print(f"Error: '{err}'")

# Function to calculate moving averages
def calculate_moving_average(df, window):
    return df['LAST'].rolling(window=window).mean()

# Function to update moving averages in sgx_daily_moving table
def update_moving_averages(connection, stock_code):
    query = f"""
    SELECT TRADE_DATE, LAST
    FROM sgx_daily_moving
    WHERE STOCK_CODE = '{stock_code}'
    ORDER BY TRADE_DATE DESC
    """
    data = pd.read_sql(query, connection)
    
    # Calculate moving averages
    data['MA5'] = calculate_moving_average(data, 5)
    data['MA10'] = calculate_moving_average(data, 10)
    data['MA20'] = calculate_moving_average(data, 20)
    
    # Update moving averages in sgx_daily_moving table
    for index, row in data.iterrows():
        trade_date = row['TRADE_DATE'].strftime('%Y-%m-%d')
        ma5 = row['MA5']
        ma10 = row['MA10']
        ma20 = row['MA20']
        
        query = f"""
        UPDATE sgx_daily_moving
        SET MA5 = {ma5}, MA10 = {ma10}, MA20 = {ma20}
        WHERE STOCK_CODE = '{stock_code}' AND TRADE_DATE = '{trade_date}'
        """
        #execute_query(connection, query)

# MySQL database configuration
host = 'localhost'
user = 'apel'
password = 'apel123'
database = 'Nama01'

# Establish connection to MySQL database
connection = create_db_connection(host, user, password, database)

# Read data from sgx_daily_working table sorted by STOCK_CODE and TRADE_DATE
#query = "SELECT TRADE_DATE, STOCK_NAME, LAST, VOLUME, STOCK_CODE FROM sgx_daily_working where TRADE_DATE>='2023-03-22' and STOCK_code in ('D05','U11','O39') ORDER BY STOCK_CODE, TRADE_DATE"
query = "SELECT TRADE_DATE, STOCK_NAME, LAST, VOLUME, STOCK_CODE FROM sgx_daily_working where TRADE_DATE>(select last_run_date from sgx_job where job_id='SGX_DAILY_MOVING') ORDER BY STOCK_CODE, TRADE_DATE"
working_df = pd.read_sql(query, connection)

# Close connection to MySQL database
if connection:
    connection.close()

# Establish connection to MySQL database again to insert data into sgx_daily_moving table
connection = create_db_connection(host, user, password, database)
j=1
# Iterate through each row of the DataFrame and insert into sgx_daily_moving table
for index, row in working_df.iterrows():
    trade_date = row['TRADE_DATE'].strftime('%Y-%m-%d')
    stock_name = row['STOCK_NAME']
    last = row['LAST']
    volume = row['VOLUME']
    stock_code = row['STOCK_CODE']
    
    # Insert data into sgx_daily_moving table
    query = f"""
    INSERT INTO sgx_daily_moving (TRADE_DATE, STOCK_NAME, LAST, VOLUME, STOCK_CODE)
    VALUES ('{trade_date}', '{stock_name}', {last}, {volume}, '{stock_code}');
    """
    execute_query(connection, query)
    j+=1
    print("j="+str(j))
    
    # Update moving averages in sgx_daily_moving table
    # update_moving_averages(connection, stock_code)
 	
# Close connection to MySQL database
if connection:
    connection.close()
