## 1. download daily file from SGX https://www.sgx.com/research-education/securities, in folder \Download 
## 2. run script l_p.sh
##    -copy the file header 
##    -cat all the files to append to the header
##    -run python (load_sgx) to load file and insert into table sgx_daily_working
##    -run python (update_sgx_ma2) to insert into table sgx_daily_moving
##    -run stored procedure (in sql) 'test1' to compute moving average (5,10.20,50,100) and daily return%, update table 
##      sgx_job for next run
##    -remove download files

cp SESprice0.txt SESprice0.dat
mv ~/Downloads/SESprice*.dat .
cat SESprice*.dat >SESprice.txt
python3 Load_sgx.py
python3 Update_sgx_ma2.py
mysql -u apel --password="apel123" --database="Nama01" <Update_sgx_ma.sql

#python3 Get_sgx_ma.py
python3 Query_sgx_1.py

rm SESprice*.dat

