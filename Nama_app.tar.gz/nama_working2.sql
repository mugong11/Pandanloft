/*Daily input
1.Download file sgx
2.add header TRADE DATE;STOCK NAME;REMARKS;CURRENCY;HIGH;LOW;LAST;CHANGE1;VOLUME;BID;OFFER;MARKET;OPEN;VALUE;STOCK CODE;DClose;
3.Load_sgx.py < l_p.sh, > sgx_daily_working
*/

/*Daily moving
1.
sgx_daily_working > sgx_daily_moving
*/
CALL `Nama01`.`test1`();
CALL `Nama01`.`LDR`();

/*Daily check-out
1. Last > MA5 > MA10 > MA20, Golden cross
2. MA20 > MA10 > MA5 > Last,  Dead cross
3. Volume up
*/
select * from sgx_daily_working where stock_code in ('P8Z') order by TRADE_DATE desc;
select * from sgx_daily_moving where stock_code in ('VOO') order by stock_code, TRADE_DATE desc;
select * from sgx_daily_moving where upper(stock_name) like '%CAPMALL%';
select count(1) from sgx_daily_working where TRADE_DATE='2024-11-06';
select count(1) from sgx_daily_moving;
select count(1) from sgx_daily_moving where ma5 is null;
select count(1) from sgx_daily_moving where ma5 is not null;
SELECT * FROM sgx_daily_moving WHERE TRADE_DATE = '2024-11-06' and LDR is  null;
SELECT * FROM sgx_daily_moving WHERE TRADE_DATE = '2024-10-10' ;
SELECT * FROM sgx_daily_moving WHERE STOCK_CODE='D05' order by trade_date desc;
select * from sgx_job;
SELECT stock_code,trade_date FROM sgx_daily_moving where trade_date>
    (select last_run_date from sgx_job where job_id='SGX_DAILY_MOVING');
update sgx_job set last_run_date='2025-06-25' where job_id='SGX_DAILY_MOVING';
select max(TRADE_DATE) from sgx_daily_moving where stock_code in ('D05');
update sgx_job set last_run_date=(select max(TRADE_DATE) from sgx_daily_moving where stock_code in ('D05')) where job_id='SGX_DAILY_MOVING';

select * from sgx_daily_working where TRADE_DATE>='2024-05-24' and stock_code like '%U';
select * from sgx_daily_working where TRADE_DATE>='2024-05-24' and lower(stock_name) like 'csop%';
SELECT * FROM sgx_daily_moving where 1=1 and stock_code='5WH' order by trade_date desc;
SELECT * FROM sgx_daily_moving where 1=1 and stock_name like '%REX%';

select count(1) from sgx_daily_moving where trade_date='2024-10-09';
select count(1) from sgx_daily_working where trade_date='2024-10-09';
delete from sgx_daily_moving where trade_date='2024-10-09';
delete from sgx_daily_working where trade_date='2024-10-09';
delete from sgx_daily_moving where trade_date>='2024-04-08' and ma5 is null;

/**********************/
select * from sgx_daily_moving where ma5>=ma10 and ma10>=ma20 and ma20>=ma50 and VOLUME>=10000 and stock_code not like '%W'  and TRADE_DATE=(select last_run_date from sgx_job where job_id='SGX_DAILY_MOVING') order by volume desc ;
select * from sgx_daily_moving where ma5>ma10 and ma10>=ma20 and ma20>=ma50 and TRADE_DATE='2024-08-08' and VOLUME>=10000 and stock_code not like '%W' order by volume desc ;
select count(1) from sgx_daily_moving where last>=ma5 and ma5>=ma10 and ma10>=ma20 and TRADE_DATE='2024-05-03' and VOLUME>=1000000 ;
select * from sgx_daily_moving where ma5>ma10 and ma10>=ma20 and ma20>=ma50 and TRADE_DATE='2024-06-25' and VOLUME>=10000 and last between 0.5 and 1 and stock_code not like '%W' order by VOLUME desc;
select * from sgx_daily_moving where ma5>ma10 and ma10>=ma20 and ma20>=ma50 and TRADE_DATE='2024-06-25' and VOLUME>=10000 and last between 0.1 and 0.5 and stock_code not like '%W'
union
select * from sgx_daily_moving where ma5>ma10 and ma10>ma20 and TRADE_DATE='2024-04-09' and VOLUME>=10000 and last between 1 and 2  and stock_code not like '%W'
union
select * from sgx_daily_moving where ma5>ma10 and ma10>ma20 and TRADE_DATE='2024-04-09' and VOLUME>=10000 and last >2  and stock_code not like '%W';

select * from sgx_daily_moving where last<=ma5 and ma5<=ma10 and ma10<=ma20 and TRADE_DATE='2024-04-02' and VOLUME>0 ;
select count(1) from sgx_daily_moving where last<=ma5 and ma5<=ma10 and ma10<=ma20 and TRADE_DATE='2024-04-02' and VOLUME>0 ;

/**********************/
/*LDR， =STDEV.P(M2:M146) =AVERAGE(M2:M146)*/
select * from sgx_daily_moving where stock_code in ('GSD') order by stock_code,TRADE_DATE desc;
select stock_code, 
FORMAT(avg(LDR)*count(1),2) ret,stddev(ldr)*sqrt(count(1)) std,count(1), avg(LDR)*count(1)/(stddev(ldr)*sqrt(count(1))) as s_ratio 
from sgx_daily_moving 
where ldr is not null
group by stock_code
/*having stock_code in ('U11','D05','O39')*/
having stock_code not like '%W' and s_ratio>0
order by s_ratio desc;

select * from 
(select stock_code, FORMAT(avg(LDR)*count(1),2) ret,FORMAT(stddev(ldr)*sqrt(count(1)),2) std,count(1), FORMAT(avg(LDR)*count(1)/(stddev(ldr)*sqrt(count(1))),2) as s_ratio from sgx_daily_moving 
where ldr is not null
group by stock_code
having stock_code in ('U11','D05','O39','5E2','ES3')
/*having stock_code not like '%W' and s_ratio>0*/
) t1, sgx_daily_moving s
where t1.stock_code = s.STOCK_CODE
and s.TRADE_DATE=(select last_run_date from sgx_job where job_id='SGX_DAILY_MOVING') 
/*and s.last <=0.50 and s.last>=0.20*/
/*
and ma5>ma10 and ma10>=ma20 
and ma20>=ma50 and VOLUME>=10000
*/
;

select log(31.93/31.76)*100 from dual;

/*Z2AB*/
select * from sgx_daily_moving where stock_code in ('Z1AB') order by stock_code,TRADE_DATE desc;
SELECT (1+DATEDIFF(sysdate(), "2024-07-22")/183*0.0317);
SELECT DATEDIFF(sysdate(), "2024-07-22")/183*0.0317;
SELECT 1.0317*1.35;

/*Housekeeping*/
delete from sgx_daily_working;

/*Backup*/
drop table sgx_daily_moving;
CREATE TABLE sgx_daily_moving (
    TRADE_DATE DATE,
    STOCK_NAME VARCHAR(30),
    LAST DECIMAL(7, 2),
    VOLUME INT(10),
    STOCK_CODE CHAR(4),
    MA5  DECIMAL(7, 2) null,
    MA10  DECIMAL(7, 2)  null,
    MA20  DECIMAL(7, 2)  null
);

drop table sgx_job;
create table sgx_job (
 job_id varchar(40),
 last_run_date date
);

insert sgx_job values ('SGX_DAILY_MOVING','2024-04-09');

CALL `Nama01`.`test1`();

select date(sysdate()-1) from dual;
SELECT * FROM sgx_daily_moving
where TRADE_DATE='2024-04-05' and stock_code='D05'
#INTO OUTFILE '~/mingsong2023/Proj_Nama/sgx_daily_moving.csv'
INTO OUTFILE '/tmp/sgx_daily_moving.csv'
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n';

/************************************/
/*sgx_monthly_screen*/
select * from sgx_monthly_screen;
delete from sgx_monthly_screen;
delete from sgx_monthly_screen_history where STOCK_CODE='P8Z'  and rec_date='2025-03-12';
delete from sgx_monthly_screen_history where rec_date='2025-07-01' and 1=1;
select count(1) from sgx_monthly_screen_history where rec_date='2025-06-02' and 1=1;
select * from sgx_monthly_screen
where pe>0 and pe<=12
and yield>=5
and 1yrrevchg+NetProfit>=40
;

/*FA: PE/Growth */
select * from 
(select stock_code, FORMAT(avg(LDR)*count(1),2) ret,FORMAT(stddev(ldr)*sqrt(count(1)),2) std,count(1), FORMAT(avg(LDR)*count(1)/(stddev(ldr)*sqrt(count(1))),2) as s_ratio from sgx_daily_moving 
where ldr is not null
group by stock_code
/*having stock_code in ('U11','D05','O39')*/
having stock_code not like '%W' /*and s_ratio>0*/
) t1, sgx_daily_moving s, sgx_monthly_screen_history s2
where t1.stock_code = s.STOCK_CODE
and VOLUME>1000
and volume>=1.5*VA30
/*and pe>0 and pe<=20 and 1yrrevchg+NetProfit*100>=40*/
and PE/1yrrevchg<1.5 and PE/1yrrevchg>0 and PriceBookValue/roe<=20
/*and yield>=5 */
and s2.STOCK_CODE=s.STOCK_CODE
/*and s2.STOCK_CODE in ('9CI','A17U','C38U','C09','D05','D01','J69U','BUOU','G13','H78','C07','J36','BN4','ME8U','M44U','N2IU','O39','S58','5E2','U96','S68','C6L','Z74','S63','Y92','U11','U14','V03','F34','BS6')*/
and s.TRADE_DATE=(select last_run_date from sgx_job where job_id='SGX_DAILY_MOVING') 
and s2.rec_date=(select last_run_date from sgx_job where job_id='SGX_MONTHLY_SCREEN') 
;

select STOCK_NAME,STOCK_CODE,LastPrice,ROE,MktCap,TotRev,PE,Yield,Sector,GTIScore,4wkPrChg,13wkPrChg,26wkPrChg,52wkPrChg,NetProfit,DebtEquity,1yrRevChg, last_run_date from sgx_monthly_screen,sgx_job where job_id='SGX_MONTHLY_SCREEN';
select * from sgx_monthly_screen_history where stock_code='D05' order by rec_date desc;
select count(1) from sgx_monthly_screen_history where rec_date=(select last_run_date from sgx_job where job_id='SGX_MONTHLY_SCREEN') ;

select * from 
(select stock_code, FORMAT(avg(LDR)*count(1),2) ret,FORMAT(stddev(ldr)*sqrt(count(1)),2) std,count(1), FORMAT(avg(LDR)*count(1)/(stddev(ldr)*sqrt(count(1))),2) as s_ratio from sgx_daily_moving 
where ldr is not null
group by stock_code
having stock_code in ('U11','D05','O39')
/*having stock_code not like '%W' and s_ratio>0*/
) t1, sgx_daily_moving s, sgx_monthly_screen_history s2
where t1.stock_code = s.STOCK_CODE
and s.TRADE_DATE=(select last_run_date from sgx_job where job_id='SGX_DAILY_MOVING') 
/*and s.last <=0.50 and s.last>=0.20*/
/*and ma5>ma10 and ma10>=ma20 and ma20>=ma50 */
/*and ma10 > ma100
and VOLUME>=10000*/
and s.STOCK_CODE=s2.stock_code
and s2.rec_date=(select last_run_date from sgx_job where job_id='SGX_MONTHLY_SCREEN') 
;

/************************************/
/*STI components*/
/************************************/
select * from sgx_monthly_screen_history
where STOCK_CODE in ('9CI','A17U','C38U','C09','D05','D01','J69U','BUOU','G13','H78','C07','J36','BN4','ME8U','M44U','N2IU','O39','S58','5E2','U96','S68','C6L','Z74','S63','Y92','U11','U14','V03','F34','BS6')
and rec_date=(select last_run_date from sgx_job where job_id='SGX_MONTHLY_SCREEN') 
order by pe asc, roe desc
;
/************************************/
/*MY_portforlio_2025*/
/************************************/
select * from sgx_monthly_screen_history
where STOCK_CODE in ('D05','P8Z','Q5T','C38U','J69U','M44U','ME8U','C2PU','E28')
/*and STOCK_CODE in ('%')*/
order by STOCK_CODE,rec_date desc
;

/*analyaze by sector*/
select sector,count(1),avg(pe),avg(PriceBookValue),avg(roe) from sgx_monthly_screen_history
where rec_date=(select last_run_date from sgx_job where job_id='SGX_MONTHLY_SCREEN') 
group by sector
;
select count(1) from sgx_monthly_screen_history
where rec_date=(select last_run_date from sgx_job where job_id='SGX_MONTHLY_SCREEN') 
;

select * from sgx_monthly_screen_history
where rec_date=(select last_run_date from sgx_job where job_id='SGX_MONTHLY_SCREEN') 
/*and sector='Utilities'*/
and PE<=20 and PE>0
and PriceBookValue<=2
and ROE>=10
and NetProfit>=0.10
and DebtEquity<=1
and LastPrice>=0.10 and LastPrice<=1
order by pe , PriceBookValue , roe desc
;

/************************************/
/*MS_transactions*/
/************************************/
select * from ms_transaction ;
select * from ms_transaction where stock_code in ('ES3');
select * from ms_transaction where account in ('CPFIS') order by trade_date;
select * from ms_transaction where stock_code like 'ES3%'  order by trade_date;
select * from ms_transaction where transaction='Sell' and remark is null and stock_code in ('D05','YLD','ES3');
/*
delete from ms_transaction  where transaction='Sell';
delete from ms_transaction  where account in ('SRS');
*/
update ms_transaction set remark='monthly RSP' where  stock_code like 'AMZN'  and Transaction='Buy' and remark is null;
update ms_transaction set remark='restart after Apr2025 Trump Tariff slump' where  seq_id=220;
update ms_transaction set amount=price*quantity+fee_tax where transaction in ('Buy') and amount is null;
update ms_transaction set STOCK_CODE='07552' where stock_code='7552';

select * from MS_STOCK_MASTER order by sector;
select * from MS_STOCK_MASTER where STOCK_CODE='NBSW';
/*delete from MS_STOCK_MASTER;*/

select stock_code, transaction, sum(amount) 
from ms_transaction
where account='P1216110'
group by stock_code, transaction
order by stock_code, transaction
;

select sum(amount) 
from ms_transaction
where account='CPFIS'
;

select transaction, sum(amount) 
from ms_transaction
group by  transaction
;

select transaction, sum(amount) 
from ms_transaction
where Stock_Code in (select Stock_Code from MS_STOCK_MASTER where currency='HKD')
group by transaction
;

/*---[analysis]*/
select * from 
ms_transaction t, sgx_daily_working d
where t.Stock_Code=d.STOCK_CODE
and t.Stock_Code='D05'
and d.TRADE_DATE=(select last_run_date from sgx_job j where j.job_id='SGX_DAILY_MOVING')
;

select account,transaction,sum(Quantity),sum(amount)
from ms_transaction t
where t.stock_code='D05'
group by account,transaction
;

select  b.q-s.q,b.a-s.a-d.a, (b.a-s.a-d.a)/(b.q-s.q) from 
(select sum(Quantity) q,sum(amount) a
from ms_transaction t
where t.stock_code='D05' and transaction='buy') b,
(select sum(Quantity) q,sum(amount) a
from ms_transaction t
where t.stock_code='D05' and transaction='sell') s,
(select sum(Quantity) q,sum(amount) a
from ms_transaction t
where t.stock_code='D05' and transaction='dividend') d
;

/*1.b.a&s.a&d.a>0,
2.b.a&s.a>0, isnull(d.a,1)
3.b.a>0, isnull(s.a,1),isnull(d.a,1)
*/
select b.stock_code,b.q buy_qty,b.a buy_amt,s.q sell_qty,s.a sell_amt,d.q div_qty,d.a div_amt,  
(b.a-if(isnull(s.a),0,s.a)-if(isnull(d.a),0,d.a))/(b.q-if(isnull(s.q),0,s.q)) avg_price,
(b.q-if(isnull(s.q),0,s.q)) net_qty
from 
(select sum(Quantity) q,sum(amount) a, t.stock_code
from ms_transaction t
where  transaction='buy'
group by t.stock_code) b
left OUTER JOIN (select sum(Quantity) q,sum(amount) a, t.stock_code
from ms_transaction t
where transaction='sell'
group by t.stock_code) s on b.stock_code=s.stock_code
left OUTER JOIN (select sum(Quantity) q,sum(amount) a, t.stock_code
from ms_transaction t
where transaction='dividend'
group by t.stock_code) d on b.stock_code=d.stock_code
;

select ms.*,pri.LAST , if(avg_price<=last,"Gain","Lost") status, ((last-avg_price)*net_qty) Profit, ((last-avg_price)/avg_price*100) Percent
from ms_stock_summary ms
left OUTER JOIN (
select * from sgx_daily_moving 
where TRADE_DATE=(select last_Run_date from sgx_job where job_id='SGX_DAILY_MOVING')) pri
on ms.stock_code=pri.STOCK_CODE
;

select * from ms_transaction where seq_id in (356,357,358);
delete from ms_transaction where seq_id in (2024);