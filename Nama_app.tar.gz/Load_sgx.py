import pandas as pd
import mysql.connector

# Function to establish a connection to MySQL database
def create_db_connection(host_name, user_name, user_password, db_name):
    connection = None
    try:
        connection = mysql.connector.connect(
            host=host_name,
            user=user_name,
            passwd=user_password,
            database=db_name
        )
        print("MySQL Database connection successful")
    except mysql.connector.Error as err:
        print(f"Error: '{err}'")

    return connection

# Function to execute SQL queries
def execute_query(connection, query):
    cursor = connection.cursor()
    try:
        cursor.execute(query)
        connection.commit()
        #print("Query executed successfully")
    except mysql.connector.Error as err:
        print(f"Error: '{err}'")

# MySQL database configuration
host = 'localhost'
user = 'apel'
password = 'apel123'
database = 'Nama01'

# Establish connection to MySQL database
connection = create_db_connection(host, user, password, database)

# Read CSV file
csv_file = 'SESprice.txt'  # Provide the path to your CSV file
df = pd.read_csv(csv_file, delimiter=';', dtype=str)  # Specify dtype as string to maintain original formatting
i=1

# Iterate through each row of the DataFrame
for index, row in df.iterrows():
    # Construct SQL query to insert data into MySQL database
    query = f"""
    INSERT INTO sgx_daily_working (trade_date, stock_name, remarks, currency, high, low, last, change1, volume, bid, offer, market, open, value, stock_code, dclose)
    VALUES ('{row['TRADE DATE']}', '{row['STOCK NAME']}', '{row['REMARKS']}', '{row['CURRENCY']}', '{row['HIGH']}', '{row['LOW']}', '{row['LAST']}', '{row['CHANGE1']}', '{row['VOLUME']}', '{row['BID']}', '{row['OFFER']}', '{row['MARKET']}', '{row['OPEN']}', '{row['VALUE']}', '{row['STOCK CODE']}', '{row['DClose']}');
    """
    # Execute SQL query
    execute_query(connection, query)
    i+=1
    print("i="+str(i))

# Close connection to MySQL database
if connection:
    connection.close()

