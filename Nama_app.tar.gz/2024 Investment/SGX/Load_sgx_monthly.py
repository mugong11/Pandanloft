import pandas as pd
import mysql.connector

# Function to establish a connection to MySQL database
def create_db_connection(host_name, user_name, user_password, db_name):
    connection = None
    try:
        connection = mysql.connector.connect(
            host=host_name,
            user=user_name,
            passwd=user_password,
            database=db_name
        )
        print("MySQL Database connection successful")
    except mysql.connector.Error as err:
        print(f"Error: '{err}'")

    return connection

# Function to execute SQL queries
def execute_query(connection, query):
    cursor = connection.cursor()
    try:
        cursor.execute(query)
        connection.commit()
        #print("Query executed successfully")
    except mysql.connector.Error as err:
        print(f"Error: '{err}'")

# MySQL database configuration
host = 'localhost'
user = 'apel'
password = 'apel123'
database = 'Nama01'

# Establish connection to MySQL database
connection = create_db_connection(host, user, password, database)

# Read CSV file
csv_file = 'sgx_Screen_working.csv'  # Provide the path to your CSV file
df = pd.read_csv(csv_file, delimiter=',', dtype={'﻿Trading Name':str, 'Code':str, 'Last Price':float, 'ROE':float, 'Mkt Cap ($M)':float, 'Tot. Rev ($M)':float,'P/E':float, 'Yield (%)':float, 'Sector':str, 'GTI Score':float, '4-wk %Pr. Chg.':float, '13-wk %Pr. Chg.':float, '26-wk %Pr. Chg.':float, '52-wk %Pr. Chg.':float, 'Net Profit':float, 'Price/CF':float,'Debt/Equity':float, '1-yr %Rev. Chg.':float,'Price/Book Value':float}).fillna(value={'Last Price':0, 'ROE':0,'Mkt Cap ($M)':0, 'Tot. Rev ($M)':0,'P/E':0, 'Yield (%)':0,'GTI Score':0, '4-wk %Pr. Chg.':0, '13-wk %Pr. Chg.':0, '26-wk %Pr. Chg.':0, '52-wk %Pr. Chg.':0, 'Net Profit':0,'Price/CF':0, 'Debt/Equity':0, '1-yr %Rev. Chg.':0,'Price/Book Value':0})  # Specify dtype as string to maintain original formatting
i=1

# Iterate through each row of the DataFrame
for index, row in df.iterrows():

    if (row['P/E']=='nan'):
    	#row['P/E']=0
    	col_pe=0
    else:
    	col_pe=row['P/E']
	
    if (row['Yield (%)']=='nan') :
    	row['Yield (%)']=0

    # Construct SQL query to insert data into MySQL database
    query = f"""
    INSERT INTO sgx_monthly_screen (STOCK_NAME, STOCK_CODE, LastPrice, ROE, MktCap, TotRev, PE, Yield, Sector, GTIScore, 4wkPrChg, 13wkPrChg, 26wkPrChg, 52wkPrChg, NetProfit, DebtEquity, 1yrRevChg,PriceCF,PriceBookValue)
    VALUES ('{row['Trading Name']}', '{row['Code']}', '{row['Last Price']}', '{row['ROE']}', '{row['Mkt Cap ($M)']}', '{row['Tot. Rev ($M)']}', '{row['P/E']}', '{row['Yield (%)']}', '{row['Sector']}', '{row['GTI Score']}', '{row['4-wk %Pr. Chg.']}', '{row['13-wk %Pr. Chg.']}', '{row['26-wk %Pr. Chg.']}', '{row['52-wk %Pr. Chg.']}', '{row['Net Profit']}', '{row['Debt/Equity']}', '{row['1-yr %Rev. Chg.']}','{row['Price/CF']}','{row['Price/Book Value']}');
    """
    # Execute SQL query
    execute_query(connection, query)
    i+=1
    print("i="+str(i)+":"+query)

# Close connection to MySQL database
if connection:
    connection.close()

