update sgx_job set last_run_date=sysdate() where job_id='SGX_MONTHLY_SCREEN';

insert into sgx_monthly_screen_history (STOCK_NAME,STOCK_CODE,LastPrice,ROE,MktCap,TotRev,PE,Yield,Sector,GTIScore,4wkPrChg,13wkPrChg,26wkPrChg,52wkPrChg,NetProfit,DebtEquity,1yrRevChg,rec_date,PriceCF,PriceBookValue) select STOCK_NAME,STOCK_CODE,LastPrice,ROE,MktCap,TotRev,PE,Yield,Sector,GTIScore,4wkPrChg,13wkPrChg,26wkPrChg,52wkPrChg,NetProfit,DebtEquity,1yrRevChg, last_run_date,PriceCF,PriceBookValue from sgx_monthly_screen,sgx_job where job_id='SGX_MONTHLY_SCREEN';

delete from sgx_monthly_screen;

