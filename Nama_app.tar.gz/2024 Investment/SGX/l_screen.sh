## 1. download monthly file from SGX https://investors.sgx.com/stock-screener, in folder \Download, Do add fields: 
##  4wkPrChg DECIMAL(9, 2),
##  13wkPrChg DECIMAL(9, 2),
##  26wkPrChg DECIMAL(9, 2),
##  52wkPrChg DECIMAL(9, 2),
##  NetProfit  DECIMAL(9, 2),
##  DebtEquity  DECIMAL(9, 2),
##  1yrRevChg   DECIMAL(9, 2),
## 2. run script l_screen.sh
##    -run python (Load_sgx_monthly) to load file and insert into table sgx_monthly_screen
##    -run sql to insert into table sgx_monthly_screen_history (additional rec_date)
##       clean table sgx_monthly_screen
## 3. housekeep the loaded file

mv ~/Downloads/SGX*.csv .
#cp ~/Downloads/SGX*.csv .
cp SGX*.csv sgx_Screen_working.csv
python3 Load_sgx_monthly.py
mysql -u apel --password="apel123" --database="Nama01" <Update_sgx_monthly_screen.sql
mv SGX*.csv archive
