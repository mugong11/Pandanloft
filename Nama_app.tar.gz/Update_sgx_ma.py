import mysql.connector
import pandas as pd
from datetime import datetime, timedelta

# Function to establish a connection to MySQL database
def create_db_connection(host_name, user_name, user_password, db_name):
    connection = None
    try:
        connection = mysql.connector.connect(
            host=host_name,
            user=user_name,
            passwd=user_password,
            database=db_name
        )
        print("MySQL Database connection successful")
    except mysql.connector.Error as err:
        print(f"Error: '{err}'")

    return connection

# Function to execute SQL queries
def execute_query(connection, query):
    cursor = connection.cursor()
    try:
        cursor.execute(query)
        connection.commit()
        print("Query executed successfully")
    except mysql.connector.Error as err:
        print(f"Error: '{err}'")

# Function to calculate moving averages
def calculate_moving_average(df, window):
    return df['LAST'].rolling(window=window).mean()

# MySQL database configuration
host = 'localhost'
user = 'apel'
password = 'apel123'
database = 'Nama01'

# Establish connection to MySQL database
connection = create_db_connection(host, user, password, database)

# Read data from sgx_daily_working table sorted by STOCK_CODE and TRADE_DATE
query = "SELECT TRADE_DATE, STOCK_NAME, LAST, VOLUME, STOCK_CODE FROM sgx_daily_working where trade_date>='2024-03-22' ORDER BY STOCK_CODE, TRADE_DATE"
working_df = pd.read_sql(query, connection)

# Close connection to MySQL database
if connection:
    connection.close()

# Compute moving averages
working_df['MA5'] = calculate_moving_average(working_df, 5)
working_df['MA10'] = calculate_moving_average(working_df, 10)
working_df['MA20'] = calculate_moving_average(working_df, 20)

# Drop NaN values resulting from the rolling mean calculation
working_df.dropna(inplace=True)

# Establish connection to MySQL database again to insert data into sgx_daily_moving table
connection = create_db_connection(host, user, password, database)

# Iterate through each row of the DataFrame and insert into sgx_daily_moving table
for index, row in working_df.iterrows():
    trade_date = row['TRADE_DATE'].strftime('%Y-%m-%d')
    stock_name = row['STOCK_NAME']
    last = row['LAST']
    volume = row['VOLUME']
    stock_code = row['STOCK_CODE']
    ma5 = row['MA5']
    ma10 = row['MA10']
    ma20 = row['MA20']
    
    # Insert data into sgx_daily_moving table
    query = f"""
    INSERT INTO sgx_daily_moving (TRADE_DATE, STOCK_NAME, LAST, VOLUME, STOCK_CODE, MA5, MA10, MA20)
    VALUES ('{trade_date}', '{stock_name}', {last}, {volume}, '{stock_code}', {ma5}, {ma10}, {ma20});
    """
    execute_query(connection, query)

# Close connection to MySQL database
if connection:
    connection.close()

