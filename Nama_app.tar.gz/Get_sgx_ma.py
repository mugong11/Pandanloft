import mysql.connector
import pandas as pd
from datetime import datetime

# Function to establish a connection to MySQL database
def create_db_connection(host_name, user_name, user_password, db_name):
    connection = None
    try:
        connection = mysql.connector.connect(
            host=host_name,
            user=user_name,
            passwd=user_password,
            database=db_name
        )
        print("MySQL Database connection successful")
    except mysql.connector.Error as err:
        print(f"Error: '{err}'")

    return connection

# Function to execute SQL queries
def execute_query(connection, query):
    cursor = connection.cursor()
    try:
        cursor.execute(query)
        print("Query executed successfully")
    except mysql.connector.Error as err:
        print(f"Error: '{err}'")

# MySQL database configuration
host = 'localhost'
user = 'apel'
password = 'apel123'
database = 'Nama01'

# Establish connection to MySQL database
connection = create_db_connection(host, user, password, database)

# Get current system date
current_date = datetime.now().strftime('%Y-%m-%d')
#current_date = '2024-04-19'

# Query data from sgx_daily_moving table where TRADE_DATE is equal to the current system date
query = f"SELECT * FROM sgx_daily_moving WHERE TRADE_DATE = '{current_date}' and VOLUME>=10000 and ma5>ma10 and ma10>ma20 and stock_code not like '%W' "
#query = f"SELECT * FROM sgx_daily_moving WHERE TRADE_DATE = '{current_date}' and VOLUME>=10000 and last>=ma5 and ma5>ma10 and ma10>ma20 and stock_code not like '%W' "
#query = f"SELECT * FROM sgx_daily_moving WHERE TRADE_DATE = '2024-04-05' and VOLUME>=10000 and last>=ma5 and ma5>ma10 and ma10>ma20 and stock_code not like '%W' "

# Read data into DataFrame
data = pd.read_sql(query, connection)

# Close connection to MySQL database
if connection:
    connection.close()

# Define output file name
output_file = f"sgx_daily_moving_{current_date.replace('-', '')}.csv"

# Write data to CSV file
data.to_csv(output_file, index=False)

print(f"Data written to {output_file}")


