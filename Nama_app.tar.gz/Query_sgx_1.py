import mysql.connector
import pandas as pd
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime

# Database connection details
db_config = {
    'host': 'localhost',  # Replace with your MySQL host
    'user': 'apel',  # Replace with your MySQL username
    'password': 'apel123',  # Replace with your MySQL password
    'database': 'Nama01'  # Replace with your database name
}

# Email details
email_config = {
    'from_email': 'msfeng@singnet.com.sg',  # Replace with sender's email
    'to_email': 'msfeng@singnet.com.sg',  # Recipient's email
    'subject': 'SGX Daily Moving Report'
}

# SQL query to execute
query = """
select * from 
(select stock_code, FORMAT(avg(LDR)*count(1),2) ret, FORMAT(stddev(ldr)*sqrt(count(1)),2) std, count(1), 
    FORMAT(avg(LDR)*count(1)/(stddev(ldr)*sqrt(count(1))),2) as s_ratio 
    from sgx_daily_moving 
    where ldr is not null
    group by stock_code
    /* having stock_code in ('U11','D05','O39') */
    having stock_code not like '%W' and s_ratio > 0
) t1, sgx_daily_moving s, sgx_monthly_screen_history s2
where t1.stock_code = s.STOCK_CODE
and s.TRADE_DATE = (select last_run_date from sgx_job where job_id = 'SGX_DAILY_MOVING') 
/* and s.last <= 0.50 and s.last >= 0.20 */
and ma5 > ma10 and ma10 >= ma20 
and ma20 >= ma50 and VOLUME >= 10000
and s.STOCK_CODE = s2.stock_code
and s2.rec_date = (select last_run_date from sgx_job where job_id = 'SGX_MONTHLY_SCREEN')
"""

# Connect to MySQL, execute the query, and save the results to a CSV file
def fetch_data_and_save_csv(db_config, query):
    connection = mysql.connector.connect(**db_config)
    try:
        df = pd.read_sql(query, connection)
        # Define output filename with the current date
        output_file = f"sgx_daily_moving_report_{datetime.now().strftime('%Y%m%d')}.csv"
        df.to_csv(output_file, index=False)
        return output_file
    finally:
        connection.close()

# Send an email with the CSV file as an attachment
def send_email_with_attachment(email_config, file_path):
    # Setup the email
    msg = MIMEMultipart()
    msg['From'] = email_config['from_email']
    msg['To'] = email_config['to_email']
    msg['Subject'] = email_config['subject']

    # Email body
    body = "Please find the attached SGX daily moving report."
    msg.attach(MIMEText(body, 'plain'))

    # Attach the CSV file
    attachment = open(file_path, "rb")
    part = MIMEBase('application', 'octet-stream')
    part.set_payload((attachment).read())
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', f"attachment; filename= {file_path}")
    msg.attach(part)

    # Send the email
    with smtplib.SMTP('smtp.singnet.com.sg', 465) as server:  # Replace with your SMTP server and port
        server.starttls()
        server.login(email_config['from_email'], 'xxxx')  # Replace with your email password
        server.sendmail(email_config['from_email'], email_config['to_email'], msg.as_string())
    print(f"Email sent to {email_config['to_email']}")

# Main function
def main():
    # Fetch data and save to CSV
    csv_file = fetch_data_and_save_csv(db_config, query)
    
    # Send the CSV as an email attachment
    #send_email_with_attachment(email_config, csv_file)

# Run the main function
if __name__ == "__main__":
    main()

