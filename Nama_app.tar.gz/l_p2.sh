#cp SESprice0.txt SESprice0.dat
#mv ~/Downloads/SESprice*.dat .
#cat SESprice*.dat >SESprice.txt
#python3 Load_sgx.py
#python3 Update_sgx_ma2.py
mysql -u apel --password="apel123" --database="Nama01" <Update_sgx_ma.sql
python3 Get_sgx_ma.py
rm SESprice*.dat
