CALL `Nama01`.`test2`();
